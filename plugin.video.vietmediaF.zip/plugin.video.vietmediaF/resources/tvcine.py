import requests
from bs4 import BeautifulSoup
import re
import urllib.parse
import urlquick, htmlement
from resources import fshare
from addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
import xbmcgui, xbmc
from datetime import timedelta

addon_url = "plugin://{}/".format(ADDON_ID)

def getlink(url,img):
    response = urlquick.get(url, max_age=60*60)
    soup = BeautifulSoup(response.content, "html.parser")

    items = []
    links = soup.find_all('a', href=lambda href: href and 'fshare.vn' in href)
    total_links = len(links)
    dialog = xbmcgui.DialogProgress()
    dialog.create('Đang lấy dữ liệu', 'Vui lòng đợi...')
    
    for i, link in enumerate(links):
        link = link.get('href')
        name,file_type,size_file = fshare.get_fshare_file_info(link)
        
        item={}
        if "folder" in link:
            playable = False
            
        else:
            playable = True
        
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=browse&url=%s' % link
        item["thumbnail"] = img
        item["icon"] = img
        item["label2"] = ""
        item["info"] = {'plot': '','size':size_file}
        items += [item]
        progress = int((i + 1) / total_links * 100)
        dialog.update(progress, 'Đang lấy dữ liệu')
    dialog.close()
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data
def listMovie(url):
    dialog = xbmcgui.DialogProgress()
    dialog.create('Đang lấy dữ liệu', 'Vui lòng đợi...')
    success = False
    for _ in range(3):
        try:
            response = urlquick.get(url, max_age=60*60)
            success = True
            break
        except Exception as e:
            xbmcgui.Dialog().notification('Lỗi', 'Không lấy được nội dung từ web', xbmcgui.NOTIFICATION_ERROR)
    if not success:
        alert("Không lấy được nội dung từ trang web")
        return
    #response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")
    divs = soup.find_all("div", {"id": lambda x: x and x.startswith("post-")})
    items = []
    t =len(divs)
    i = 0
    for div in divs:
        name = div.find('h2', class_='movie-title').text.strip()
        vietsub = div.find("span", class_=lambda value: value and value.startswith("item-quality"))
        if vietsub:
            vietsub = vietsub.text.strip()
        else:
            vietsub = "No sub"
        rating = div.find("span", class_="movierating movierating-green")
        if rating:
            rating = rating.text.strip()
            rating = "Rating: [COLOR yellow]%s[/COLOR]" % rating
        else:
            rating = ""
        
        img = div.find("img", class_="lazy")
        if img:
            img = img.get("data-src")
        else:
            img = ""
        description = div.find("p", class_="movie-description")
        if description:
            description = description.text.strip()
            description = rating+"\n"+description
        else:
            description = ""
        year = div.find("span", class_="movie-date")
        if year:
            year = year.text.strip()
        else:
            year = ""
        link = div.find("a")["href"]
        progress = int(i) * 100 / t
        dialog.update(int(progress), "Đang lấy dữ liệu...")
        item = {}
        item["label"] = name + " [COLOR dimgrey][I]%s[/I][/COLOR]" % vietsub
        item["is_playable"] = False
        item["path"] = addon_url + "browse&url="+link
        item["thumbnail"] = img
        item["icon"] = img
        item["label2"] = "VMF"
        item["info"] = {'plot': description}
        items += [item]
        i +=1
        
    #Nextpage
    if "page" in url:
        next_page =  re.search(r"/(\d+)/$", url).group(1)
        next_page = int(next_page)+1
        base_url = re.search(r"(.*\/)page",url).group(1)
    else:
        next_page = "2"
        base_url = url
    next_page_url = base_url+"page/%s/" % next_page
    
    response = requests.head(next_page_url)
    status_code = response.status_code
    if status_code == 200:
    
        next_page_url = addon_url + "browse&url=vmf"+next_page_url
        nextpage = {"label": '[COLOR yellow]Trang %s[/COLOR] ' % next_page, "is_playable": False,
                    "path": next_page_url, "thumbnail": 'https://i.imgur.com/yCGoDHr.png', "icon": "https://i.imgur.com/yCGoDHr.png", "label2": "", "info": {'plot': 'Trang tiếp TVCN'}}
        items.append(nextpage)
    xbmc.executebuiltin('DialogProgress.close()')
    
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    dialog.close()
    return data

def receive(url):
    if "menu" in url:
        names = ["Tìm kiếm","Phim Lẻ","Phim Bộ","Xu hướng","Thể loại","Quốc gia","Chất lượng"]
        links = ["plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/timkiem/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/movies/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/tv-series/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/top/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/theloai",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/quocgia","plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/chatluong"]
        items = []
        
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = link
            item["thumbnail"] = "https://i.imgur.com/GXyTFfi.png"
            item["icon"] = "https://i.imgur.com/GXyTFfi.png"
            item["label2"] = ""
            item["info"] = {'plot': ''}
            item["art"] = {'fanart': "https://i.imgur.com/LkeOoN3.jpg"}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "tv-series" in url or "/top/" in url or "/movies/" in url or "vmf" in url:
        if "vmf" in url:
            url = url.replace("vmf","")
        match = re.search(r"url=(.*)",url)
        if match:
            url = match.group(1)
        data = listMovie(url)
        return data
    elif "theloai" in url:
        links = ['vmfhttps://thuviencine.com/adventure/', 'vmfhttps://thuviencine.com/chuong-trinh-truyen-hinh/', 'vmfhttps://thuviencine.com/kids/', 'vmfhttps://thuviencine.com/phim-bi-an/', 'vmfhttps://thuviencine.com/phim-chien-tranh/', 'vmfhttps://thuviencine.com/phim-chinh-kich/', 'vmfhttps://thuviencine.com/phim-gay-can/', 'vmfhttps://thuviencine.com/phim-gia-dinh/', 'vmfhttps://thuviencine.com/phim-gia-tuong/', 'vmfhttps://thuviencine.com/phim-hai/', 'vmfhttps://thuviencine.com/phim-hanh-dong/', 'vmfhttps://thuviencine.com/phim-hinh-su/', 'vmfhttps://thuviencine.com/phim-hoat-hinh/', 'vmfhttps://thuviencine.com/phim-khoa-hoc-vien-tuong/', 'vmfhttps://thuviencine.com/phim-kinh-di/', 'vmfhttps://thuviencine.com/phim-lang-man/', 'vmfhttps://thuviencine.com/phim-lich-su/', 'vmfhttps://thuviencine.com/phim-mien-tay/', 'vmfhttps://thuviencine.com/phim-nhac/', 'vmfhttps://thuviencine.com/phim-phieu-luu/', 'vmfhttps://thuviencine.com/phim-tai-lieu/', 'vmfhttps://thuviencine.com/reality/', 'vmfhttps://thuviencine.com/science-fiction/', 'vmfhttps://thuviencine.com/soap/', 'vmfhttps://thuviencine.com/war-politics/']
        names = ['Adventure', 'Chương Trình Truyền Hình', 'Kids', 'Phim Bí Ẩn', 'Phim Chiến Tranh', 'Phim Chính Kịch', 'Phim Gây Cấn', 'Phim Gia Đình', 'Phim Giả Tượng', 'Phim Hài', 'Phim Hành Động', 'Phim Hình Sự', 'Phim Hoạt Hình', 'Phim Khoa Học Viễn Tưởng', 'Phim Kinh Dị', 'Phim Lãng Mạn', 'Phim Lịch Sử', 'Phim Miền Tây', 'Phim Nhạc', 'Phim Phiêu Lưu', 'Phim Tài Liệu', 'Reality', 'Science Fiction', 'Soap', 'War & Politics']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = ""
            item["icon"] = ""
            item["label2"] = ""
            item["info"] = {'plot': ''}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "quocgia" in url:
        names =['Việt Nam','Anh', 'Argentina', 'Australia', 'Austria', 'Belgium', 'Bosnia and Herzegovina', 'Brazil', 'Cambodia', 'Canada', 'Chile', 'China', 'Colombia', 'Czech Republic', 'Denmark', 'Dominican Republic', 'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Ireland', 'Israel', 'Italy', 'Japan', 'Korea', 'Latvia', 'Lithuania', 'Luxembourg', 'Malaysia', 'Mexico', 'Mỹ', 'N/A', 'Netherlands', 'New Zealand', 'Nigeria', 'Norway', 'Peru', 'Philippines', 'Phim bộ Mỹ', 'Poland', 'Portugal', 'Romania', 'Russia', 'Singapore', 'Slovakia', 'South Africa', 'South Korea', 'Spain', 'Sweden', 'Switzerland', 'Taiwan', 'Thailand', 'Tunisia', 'Turkey', 'UK', 'Ukraine', 'Uruguay', 'Venezuela']
        links=['vmfhttps://thuviencine.com/country/vietnam/','vmfhttps://thuviencine.com/country/united-kingdom/', 'vmfhttps://thuviencine.com/country/argentina/', 'vmfhttps://thuviencine.com/country/australia/', 'vmfhttps://thuviencine.com/country/austria/', 'vmfhttps://thuviencine.com/country/belgium/', 'vmfhttps://thuviencine.com/country/bosnia-and-herzegovina/', 'vmfhttps://thuviencine.com/country/brazil/', 'vmfhttps://thuviencine.com/country/cambodia/', 'vmfhttps://thuviencine.com/country/canada/', 'vmfhttps://thuviencine.com/country/chile/', 'vmfhttps://thuviencine.com/country/china/', 'vmfhttps://thuviencine.com/country/colombia/', 'vmfhttps://thuviencine.com/country/czech-republic/', 'vmfhttps://thuviencine.com/country/denmark/', 'vmfhttps://thuviencine.com/country/dominican-republic/', 'vmfhttps://thuviencine.com/country/estonia/', 'vmfhttps://thuviencine.com/country/finland/', 'vmfhttps://thuviencine.com/country/france/', 'vmfhttps://thuviencine.com/country/germany/', 'vmfhttps://thuviencine.com/country/greece/', 'vmfhttps://thuviencine.com/country/hong-kong/', 'vmfhttps://thuviencine.com/country/hungary/', 'vmfhttps://thuviencine.com/country/iceland/', 'vmfhttps://thuviencine.com/country/india/', 'vmfhttps://thuviencine.com/country/indonesia/', 'vmfhttps://thuviencine.com/country/ireland/', 'vmfhttps://thuviencine.com/country/israel/', 'vmfhttps://thuviencine.com/country/italy/', 'vmfhttps://thuviencine.com/country/japan/', 'vmfhttps://thuviencine.com/country/korea/', 'vmfhttps://thuviencine.com/country/latvia/', 'vmfhttps://thuviencine.com/country/lithuania/', 'vmfhttps://thuviencine.com/country/luxembourg/', 'vmfhttps://thuviencine.com/country/malaysia/', 'vmfhttps://thuviencine.com/country/mexico/', 'vmfhttps://thuviencine.com/country/usa/', 'vmfhttps://thuviencine.com/country/n-a/', 'vmfhttps://thuviencine.com/country/netherlands/', 'vmfhttps://thuviencine.com/country/new-zealand/', 'vmfhttps://thuviencine.com/country/nigeria/', 'vmfhttps://thuviencine.com/country/norway/', 'vmfhttps://thuviencine.com/country/peru/', 'vmfhttps://thuviencine.com/country/philippines/', 'vmfhttps://thuviencine.com/country/united-states/', 'vmfhttps://thuviencine.com/country/poland/', 'vmfhttps://thuviencine.com/country/portugal/', 'vmfhttps://thuviencine.com/country/romania/', 'vmfhttps://thuviencine.com/country/russia/', 'vmfhttps://thuviencine.com/country/singapore/', 'vmfhttps://thuviencine.com/country/slovakia/', 'vmfhttps://thuviencine.com/country/south-africa/', 'vmfhttps://thuviencine.com/country/south-korea/', 'vmfhttps://thuviencine.com/country/spain/', 'vmfhttps://thuviencine.com/country/sweden/', 'vmfhttps://thuviencine.com/country/switzerland/', 'vmfhttps://thuviencine.com/country/taiwan/', 'vmfhttps://thuviencine.com/country/thailand/', 'vmfhttps://thuviencine.com/country/tunisia/', 'vmfhttps://thuviencine.com/country/turkey/', 'vmfhttps://thuviencine.com/country/uk/', 'vmfhttps://thuviencine.com/country/ukraine/', 'vmfhttps://thuviencine.com/country/uruguay/', 'vmfhttps://thuviencine.com/country/venezuela/']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = ""
            item["icon"] = ""
            item["label2"] = ""
            item["info"] = {'plot': ''}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "chatluong" in url:
        links=['vmfhttps://thuviencine.com/quality/vietsub/', 'vmfhttps://thuviencine.com/quality/tm-pd/', 'vmfhttps://thuviencine.com/quality/tm-lt-pd/', 'vmfhttps://thuviencine.com/quality/tm/', 'vmfhttps://thuviencine.com/quality/raw/', 'vmfhttps://thuviencine.com/quality/phim-viet/', 'vmfhttps://thuviencine.com/quality/new/', 'vmfhttps://thuviencine.com/quality/lt-pd/', 'vmfhttps://thuviencine.com/quality/lt/', 'vmfhttps://thuviencine.com/quality/hd/', 'vmfhttps://thuviencine.com/quality/engsub/', 'vmfhttps://thuviencine.com/quality/cam-vietsub/', 'vmfhttps://thuviencine.com/quality/cam/', 'vmfhttps://thuviencine.com/quality/bluray-vietsub/', 'vmfhttps://thuviencine.com/quality/bluray-tm-pd/', 'vmfhttps://thuviencine.com/quality/bluray/', 'vmfhttps://thuviencine.com/quality/4k-vietsub/', 'vmfhttps://thuviencine.com/quality/4k-tm/', 'vmfhttps://thuviencine.com/quality/4k-lt/', 'vmfhttps://thuviencine.com/quality/4k/']
        names= ['Vietsub', 'TM - PĐ', 'TM - LT - PĐ', 'TM', 'Raw', 'Phim Việt', 'NEW', 'LT - PĐ', 'LT', 'HD', 'Engsub', 'CAM Vietsub', 'CAM', 'Bluray Vietsub', 'Bluray TM - PĐ', 'Bluray', '4K Vietsub', '4K TM', '4K LT', '4K']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = ""
            item["icon"] = ""
            item["label2"] = ""
            item["info"] = {'plot': ''}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
        
    elif "/timkiem/" in url:
        keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
            query = urllib.parse.unquote(query)
            url = "https://thuviencine.com/?s=%s" % query
            data = listMovie(url)
            return data
        else:
            alert("Không có gì được nhập vào.")
            exit()
        
    else:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, "html.parser")
        movie_image = soup.find("div", class_="movie-image")
        if movie_image:
            image = movie_image.find("img")["src"]
        else:image=""
            
        download_button = soup.find("li", id="download-button")
        if download_button:
            link = download_button.find("a")["href"]
            data = getlink(link,image)
        else:
            alert("Không tìm thấy link. Thử lại sau")
            exit()
    return data