import requests
import xbmcgui,xbmc,xbmcvfs
import time
import os, sys

from addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE


def download_file(url, path):
    # Tính toán kích thước file
    response = requests.head(url)
    size = int(response.headers.get("Content-Length", 0))
    file_name = url.split('/')[-1]
    path = os.path.join(path, file_name)
    
    if xbmcvfs.exists(path):
        dialog = xbmcgui.Dialog()
        overwrite = dialog.yesno("File Exists", "Bạn có muốn xoá đè file cũ không?")
        if not overwrite:
            return False
            
    # Tạo progress dialog
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading...", file_name)

    def download():
        start_time = time.time()
        downloaded = 0
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        progress = int(downloaded / size * 100)
                        speed = downloaded / (time.time() - start_time)
                        time_left = (size - downloaded) / speed if speed > 0 else 0
                        dp.update(progress, "Speed: {:.2f} MB/s\nSize: {:.2f} MB\n{}% completed\nTime left: {}".format(speed / 1024 / 1024, size / 1024 / 1024, progress, time.strftime('%H:%M:%S', time.gmtime(time_left))))
                        if dp.iscanceled():
                            alert("Huỷ tải file thành công")
                            os.remove(path)
                            return

        dp.close()
        alert('Download Completed', 'File download completed.')
        if xbmcgui.Dialog().yesno("Play file?", "Bạn có muốn play luôn video này không?"):
            xbmc.Player().play(path)
            return
  
    download()