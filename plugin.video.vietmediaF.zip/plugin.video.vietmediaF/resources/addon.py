import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
import os
import datetime as dt, time
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PROFILE = ADDON.getAddonInfo("profile")
VERSION = ADDON.getAddonInfo("version")
LOG = os.path.join(xbmcvfs.translatePath('special://logpath/'))
PROFILE = os.path.join(xbmcvfs.translatePath('special://profile/'))
CURRENT_PATH = ADDON.getAddonInfo("path")
PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
USER_PIN_CODE = ADDON.getSetting('user_pin_code')
USER_VIP_CODE = ADDON.getSetting('user_vip_code')
def notify(message='', header=None, time=5000, image=None):
  	if header is None:
  		header = ADDON_NAME
  	xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' % (header, message, time,image))



def alert(message,title=ADDON_NAME+" " +VERSION):
    dialog = xbmcgui.Dialog()
    ok = dialog.ok(title,message)

def TextBoxes(heading,announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) 
			self.win=xbmcgui.Window(self.WINDOW) 
			xbmc.sleep(500) # 
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)
def debug(text):
    text = str(text)
    filename = os.path.join(PROFILE_PATH, 'debug.dat')
    if not os.path.exists(filename):
        with open(filename, "w+") as f:
            f.write(text)
    else:
        with open(filename, "w") as f:
            f.write(text)
def fetch_data(url, headers=None):
    
    if headers is None:
        headers = {
                'User-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                'Referers': 'http://www.google.com',
                'X-Version': VERSION,
                'X-User-VIP': USER_VIP_CODE
                }
    try:
        response = requests.get(url, headers=headers)
        
        return json.loads(response.content.decode('utf-8'))
    except:
        pass