import urlquick, re, json
import six
from six.moves import urllib_parse, html_parser
import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
import codecs
import sys,re,os
import getlink
from addon import alert, notify, TextBoxes, LOG
import concurrent.futures
from resources.loadlistitem import *

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PROFILE = ADDON.getAddonInfo("profile")
PROFILE = os.path.join(xbmcvfs.translatePath('special://profile/'))
PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
HISTORY_FILE = os.path.join(PROFILE_PATH, 'lstk.dat')
def debug1(text):
   
    filename = os.path.join(PROFILE_PATH, 'debug1.dat')
    if not os.path.exists(filename):
        with open(filename, "w+") as f:
            f.write(text)
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))
            
def fetch_data(url, headers=None):
    if headers is None:
        headers = {
                'User-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                'Referers': 'http://www.google.com',
                }
    try:
        req = urlquick.get(url, headers=headers,max_age=60*60)
        return json.loads(req.content)
    except:
        pass
#Save search history
def savesearch(queryText,url):
    entry = f"{queryText},{url}"
    filename = os.path.join(PROFILE_PATH, 'searchhistory.dat')
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(entry)
    else:
        with open(filename,encoding="utf-8") as file:
            content = file.read()
            if url not in content:
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(entry +'\n'+ content)
   
def searchPhongblack1(queryText):
    url = "http://kodi.s2lsolutions.com/search.php?author=phongblack&search=" + queryText
    data = fetch_data(url)
    #Remove
    items_to_remove = []
    for item in data['items']:
        if 'Kết quả từ' in item['label']:
            items_to_remove.append(item)
    for item in items_to_remove:
        data['items'].remove(item)
    
    return data
def timfshare(query):
    api_timfshare = 'https://api.timfshare.com/v1/string-query-search?query='

    headers = {
        'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'
    }
    

    r = urlquick.post(api_timfshare+query,headers=headers)
    jsondata = json.loads(r.content)
    items = []
    for i in jsondata['data']:
        item = {}
        name = i['name']
        furl = i['url']
        furl = re.search(r"(.*)\?",furl).group(1)
        filesize = float(i["size"])
        type_f = i['file_type']
        if '0' in str(type_f):
                link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % furl)
                playable = False
        else:
            link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % furl)
            playable = True
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = link
        item["thumbnail"] = 'fshare.png'
        item["icon"] = "fshareicon.png"
        item["label2"] = ""
        item["info"] = {'plot': '','size':filesize}
        items += [item]
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    valid_extensions = ['.mkv', '.mp4', '.wmv', '.iso', '.ISO', '.ts']
    new_items = []

    for item in data['items']:
        label = item['label']
        extension = label[label.rfind('.'):].lower()
        if extension in valid_extensions:
            new_items.append(item)

    data['items'] = new_items
    return data
def searchtvhd(query):
    #send keyword to searchtvhd
    data = fetch_data("https://thuvienhd.com/?feed=fsharejson&search=" + query)
   
    items = []
   
    #filesize = ''
    for x in data:
        image = x["image"]
        
        for i in x['links']:
            item = {}
            name = i['title']
            flink = i['link']
            file_type, name, file_size = getlink.checkFileInfo(flink)
            if "file" in flink:
                link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % flink)
                playable = True
            else:
                link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % flink)
                playable = False
            item["label"] = name
            item["is_playable"] = playable
            item["path"] = link
            item["thumbnail"] = image
            item["icon"] = image
            item["label2"] = ""
            item["info"] = {'plot': '','size':file_size}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        valid_extensions = ['.mkv', '.mp4', '.wmv', '.iso', '.ISO', '.ts']
        new_items = []

        for item in data['items']:
            label = item['label']
            extension = label[label.rfind('.'):].lower()
            if extension in valid_extensions:
                new_items.append(item)

        data['items'] = new_items
        return data
    
def luutimkiem(queryText):
    entry = queryText
    filename = os.path.join(PROFILE_PATH, 'lstk.dat')
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(entry)
    else:
        with open(filename,encoding="utf-8") as file:
            content = file.read()
            if entry not in content:
                with open(filename, "w", encoding="utf-8") as f:
                        f.write(entry +'\n'+ content)
def search(queryText):
    luutimkiem(queryText)
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create('[COLOR yellow]Tìm kiếm...[/COLOR]', '[COLOR yellow]Oạch oạch, đang lấy thông tin nào...[/COLOR]')
    #
    with concurrent.futures.ThreadPoolExecutor() as executor:
        # Submit the futures
        future1 = executor.submit(searchPhongblack1, queryText)
        future2 = executor.submit(timfshare, queryText)
        future3 = executor.submit(searchtvhd, queryText)

        # Use as_completed to wait for the futures to complete and cancel any that take more than 20 seconds
        results = []
        for future in concurrent.futures.as_completed([future1, future2, future3], timeout=20):
            try:
                result = future.result()
            except Exception as e:
                # Handle exceptions that may have occurred in the future
                debug1(f"Exception occurred: str({e})")
            else:
                results.append(result)
            if future.running() and (len(results) < 3) and (future not in results):
                # Cancel the future if it's still running and the other futures haven't completed yet
                future.cancel()
        data1 = future1.result()
        data2 = future2.result()
        data3 = future3.result()

    data = {}
    data['content_type'] = data1['content_type']
    data['items'] = data1['items']
    data['items'].extend(data2['items'])
    data['items'].extend(data3['items'])
    progress_dialog.close()

    return data
def search_with_no_history():
    keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh:")
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        query = keyboard.getText()
        # save query to history file
        if not os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                f.write("")

        with open(HISTORY_FILE, encoding="utf-8") as file:
            content = file.read()
            if query not in content:
                with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                    f.write(query +'\n'+ content)
        data=searchPhongblack1(query)
        list_item(data)
def search_menu_items():
    alert("search_menu_items")
    if os.path.exists(HISTORY_FILE) and os.path.getsize(HISTORY_FILE) > 0:
        path = "plugin://plugin.video.vietmediaf?action=__ducnn"
        
        history_item = xbmcgui.ListItem(label="Tìm kiếm", path=path)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="plugin://plugin.video.vietmediaf?action=__search__history", listitem=history_item, isFolder=True)
        # read history file and create list items for each query
        with open(HISTORY_FILE, "r") as f:
            lines = f.readlines()
            for line in reversed(lines):
                line = line.strip()
                if line:
                    history_item = xbmcgui.ListItem(label=line, path="?search=" + line)
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=path, listitem=history_item, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
    else:
        search_with_no_history()
        