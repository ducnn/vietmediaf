import xbmcgui, os, sys
import xbmcplugin

def update_item(name, url, thumbnail=None, plot=None, playable=True, filesize=None):
    
    item={}
    item["label"] = name
    item["path"] = url
    item["is_playable"] = playable
    item["thumbnail"] = thumbnail
    item["icon"] = thumbnail
    item["label2"] = ""
    item["info"] = {'plot': plot,'size':filesize}
    return [item]
def create_data(items):
    data = {"content_type": "episodes", "items": items}
    return data
def update_data(data,items):
    data.update({"items": items})
    return data
def list_items(data):
    if data:
        for item in data['items']:
            list_item = xbmcgui.ListItem(label=item['label'], label2=item['label2'])
            list_item.setArt({'icon': item['icon'], 'thumb': item['thumbnail']})
            info = {
                'plot': item['info']['plot'],
                'genre': item['info']['genre'],
                'year': item['info']['year']
            }
            list_item.setInfo(type='video', infoLabels=info)
            video_info = xbmcgui.ListItem().getInfoTag()
            audio_info = xbmcgui.ListItem().getInfoTag()
            subtitle_info = xbmcgui.ListItem().getInfoTag()
            if item.get("stream_info"):
                for type_, values in item["stream_info"].items():
                    if type_ == 'video':
                        video_info.addVideoStream({
                            'codec': values['codec'],
                            'width': values['width'],
                            'height': values['height'],
                            'duration': values['duration'],
                            'aspect': values['aspect'],
                            'fps': values['fps']
                        })
                    elif type_ == 'audio':
                        audio_info.addAudioStream({
                            'codec': values['codec'],
                            'language': values['language'],
                            'channels': values['channels']
                        })
                    elif type_ == 'subtitle':
                        subtitle_info.addSubtitleStream({
                            'language': values['language']
                        })
            list_item.addStreamInfo('video', video_info)
            list_item.addStreamInfo('audio', audio_info)
            list_item.addStreamInfo('subtitle', subtitle_info)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=item['path'], listitem=list_item, isFolder=not item['is_playable'])
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        xbmcgui.Dialog().ok('Error', 'Failed to retrieve data')
        sys.exit()

'''
def list_items(data):
    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(int(sys.argv[1]), data["content_type"])

    for item in data["items"]:
        list_item = xbmcgui.ListItem(label=item["label"], label2=item["label2"])
        list_item.setArt({'icon': item['icon'], 'thumb': item['thumbnail']})
        if item.get("info"):
            list_item.setInfo(type='video', infoLabels=item["info"])
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                list_item.addStreamInfo(type_, values)
        if item.get("art"):
            list_item.setArt(item["art"])
        list_item.setArt({'thumb': item["thumbnail"], 'icon': item["thumbnail"], 'poster': item["icon"]})
        list_item.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                list_item.setProperty(k, v)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=item["path"], listitem=list_item, isFolder=not item["is_playable"])

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, updateListing=False, cacheToDisc=True)
'''