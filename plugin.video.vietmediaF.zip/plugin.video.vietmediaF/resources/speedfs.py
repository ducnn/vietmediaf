import requests #line:1
import xbmcgui ,xbmc ,xbmcvfs #line:2
import os ,sys ,time ,json ,random ,base64 #line:3
from resources import fshare #line:4
from addon import alert ,notify ,TextBoxes ,ADDON ,ADDON_ID ,ADDON_PROFILE ,LOG ,PROFILE #line:5
USERDATA =os .path .join (xbmcvfs .translatePath ('special://home/'),'userdata')#line:6
path =xbmcvfs .translatePath (USERDATA +"/test.zip")#line:7
fshare .check_session ()#line:8
session_id =ADDON .getSetting ('sessionfshare')#line:9
token =ADDON .getSetting ('tokenfshare')#line:10
def links ():#line:14
    OO0O0OO0O0OO00OO0 =base64 .b64decode ('aHR0cHM6Ly93d3cuZnNoYXJlLnZuL2ZvbGRlci8yOVZDVFZMMjdLWFQ=').decode ('utf-8')#line:15
    O00000000O0000OOO ='kodivietmediaf-K58W6U'#line:16
    OOO00OO000OO0OO0O ={'User-Agent':O00000000O0000OOO ,'Cookie':'session_id=%s'%session_id }#line:21
    OOOOOOOOOOO000O00 =0 #line:22
    O00O00OO0000O0000 ={'token':token ,'url':OO0O0OO0O0OO00OO0 ,'dirOnly':0 ,'pageIndex':OOOOOOOOOOO000O00 ,'limit':60 ,}#line:23
    O000OO000OOOO0O00 ="https://api.fshare.vn/api/fileops/getFolderList"#line:24
    OO0O0O000000OOO00 =requests .post (O000OO000OOOO0O00 ,headers =OOO00OO000OO0OO0O ,json =O00O00OO0000O0000 )#line:26
    if OO0O0O000000OOO00 :#line:28
        O0OOO0OOO000000OO =(OO0O0O000000OOO00 .content ).decode ("utf-8")#line:29
        O00OOOO0OO0000O00 =[]#line:30
        O0OOO0OOO000000OO =json .loads (O0OOO0OOO000000OO )#line:31
        for OO000O0OO0OO00000 in O0OOO0OOO000000OO :#line:32
            O00OO000OOO00OO00 =OO000O0OO0OO00000 ['furl']#line:33
            O00OOOO0OO0000O00 +=[O00OO000OOO00OO00 ]#line:34
        return (random .choice (O00OOOO0OO0000O00 ))#line:35
def sppedfs ():#line:38
    OO0O0000000OOO0OO =links ()#line:39
    OO0O0000000OOO0OO =fshare .get_download_link (token ,session_id ,OO0O0000000OOO0OO )#line:40
    O000O00OOOO00OOO0 =requests .head (OO0O0000000OOO0OO )#line:41
    O000O000000000O0O =int (O000O00OOOO00OOO0 .headers .get ("Content-Length",0 ))#line:42
    if xbmcvfs .exists (path ):#line:43
        os .remove (path )#line:44
    OO000O0OO0OOOOO00 =xbmcgui .DialogProgress ()#line:45
    OO000O0OO0OOOOO00 .create ("Đo tốc độ Fshare...","")#line:46
    def O0O0OO000O000OO00 ():#line:47
        O0OO0O0OO0O0O0O00 =time .time ()#line:48
        OO0O000OOO0000O00 =0 #line:49
        OOO0OOOO0000O0000 =8192 #line:50
        OOOO0OO00O0OO0OO0 =[]#line:51
        with requests .get (OO0O0000000OOO0OO ,stream =True )as OOOO00OOOO000O00O :#line:52
            OOOO00OOOO000O00O .raise_for_status ()#line:53
            with open (path ,"wb")as OOO0O00OOOOOOOO00 :#line:54
                for OO0O00OOO000000O0 in OOOO00OOOO000O00O .iter_content (chunk_size =OOO0OOOO0000O0000 ):#line:55
                    if OO0O00OOO000000O0 :#line:56
                        OOO0O00OOOOOOOO00 .write (OO0O00OOO000000O0 )#line:57
                        OO0O000OOO0000O00 +=len (OO0O00OOO000000O0 )#line:58
                        O0OO0OO0O0O00OOOO =int (OO0O000OOO0000O00 /O000O000000000O0O *100 )#line:59
                        O0OOO0O000O00O0O0 =OO0O000OOO0000O00 /(time .time ()-O0OO0O0OO0O0O0O00 )#line:60
                        O0O0OO0O00O0OO0O0 =(O000O000000000O0O -OO0O000OOO0000O00 )/O0OOO0O000O00O0O0 if O0OOO0O000O00O0O0 >0 else 0 #line:61
                        OO000O0OO0OOOOO00 .update (O0OO0OO0O0O00OOOO ,"Tốc độ hiện tại đến Fshare: [COLOR yellow]{:.2f} MB/s[/COLOR]\n{}%  quá trình kiểm tra\nThời gian còn lại: {}".format (O0OOO0O000O00O0O0 /1024 /1024 ,O0OO0OO0O0O00OOOO ,time .strftime ('%H:%M:%S',time .gmtime (O0O0OO0O00O0OO0O0 ))))#line:62
                        if OO000O0OO0OOOOO00 .iscanceled ():#line:64
                            xbmcgui .Dialog ().ok ("Thông báo","Huỷ đo tốc độ thành công")#line:65
                            os .remove (path )#line:66
                            return #line:67
        OO000O0OO0OOOOO00 .close ()#line:69
        OO0O0OOOO0OOO000O =time .time ()#line:70
        O00OO0OO0OOO0OOOO =OO0O0OOOO0OOO000O -O0OO0O0OO0O0O0O00 #line:71
        O000O00O0000O0OOO =OO0O000OOO0000O00 /O00OO0OO0OOO0OOOO #line:72
        OO00OOOOOO0O0O0O0 =round (O000O00O0000O0OOO /1024 /1024 ,2 )#line:73
        OO000O00O00OOO000 (OO00OOOOOO0O0O0O0 )#line:74
    def OO000O00O00OOO000 (OOO0O0000OOO0OO0O ):#line:75
        O00O0O000O0OOO0O0 =xbmcgui .Dialog ()#line:76
        O00000OOO000OO000 ="SD (360p)"#line:77
        if OOO0O0000OOO0OO0O >=50 :#line:78
            O00000OOO000OO000 ="ISO 4K"#line:79
        elif OOO0O0000OOO0OO0O >=20 :#line:80
            O00000OOO000OO000 ="Video 4K H.264 (AVC)"#line:81
        elif OOO0O0000OOO0OO0O >=10 :#line:82
            O00000OOO000OO000 ="Video 4K H.265 (HEVC)"#line:83
        elif OOO0O0000OOO0OO0O >=5 :#line:84
            O00000OOO000OO000 ="Video 1080p"#line:85
        elif OOO0O0000OOO0OO0O >=2 :#line:86
            O00000OOO000OO000 ="Video 720p"#line:87
        O00O0O000O0OOO0O0 .ok ("Đề xuất chất lượng video",f"Chất lượng video phù hợp với tốc độ [COLOR yellow]{OOO0O0000OOO0OO0O} MB/s[/COLOR] của bạn là: [COLOR yellow]{O00000OOO000OO000}[/COLOR]")#line:88
    O0O0OO000O000OO00 ()#line:90
