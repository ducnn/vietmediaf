import sys
import urlquick,htmlement
import os
from resources import loadlistitem, addon
import getlink
import datetime as dt
import time
import remove_accents
import requests
import importlib
import json
import re
import urllib.parse
from requests.utils import requote_uri
import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
import six
from six.moves import urllib_parse, html_parser
from config import VIETMEDIA_HOST
from addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
from resources import search



# importlib.reload(sys)
HANDLE = int(sys.argv[1])


ADDON_NAME = ADDON.getAddonInfo("name")
_icon = ADDON.getAddonInfo('icon')
_fanart = ADDON.getAddonInfo('fanart')
CURRENT_PATH = ADDON.getAddonInfo("path")

PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
VERSION = ADDON.getAddonInfo("version")
USER = ADDON.getSetting('user_id')

USER_PIN_CODE = ADDON.getSetting('user_pin_code')
USER_VIP_CODE = ADDON.getSetting('user_vip_code')
LOCK_PIN = ADDON.getSetting('lock_pin')
VIEWMODE = ADDON.getSetting('view_mode')
advtxt1 = 'http://vietmediaf.net/adv.txt'
advtxt2 = 'https://pastebin.com/raw/q0H6dYbR'
VIEWXXX = ADDON.getSetting('view_xxx')
DOWNLOAD_PATH = ADDON.getSetting("download_path")
DOWNLOAD_SUB = ADDON.getSetting("download_sub")
DIALOG = xbmcgui.Dialog()
vDialog = xbmcgui.DialogProgress()
HOME = xbmcvfs.translatePath('special://home/')
USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)
CHECK = ADDON.getSetting("check")
HISTORY_FILE = os.path.join(PROFILE_PATH, 'lstk.dat')
HISTORY_FILE_4S = os.path.join(PROFILE_PATH, 'lstk4s.dat')
f_icon = xbmcvfs.translatePath('special://home/addons/'+ADDON_ID+'/fs.png')
fourshare_icon = xbmcvfs.translatePath('special://home/addons/'+ADDON_ID+'/4s.png')

disclaimer = "Addon này được cung cấp như một chương trình con chạy trong KODI. Nhà phát triển của addon không chịu trách nhiệm về bản quyền, nội dung, video, phim hoặc các clip hiển thị trong addon. Các nội dung trong addon đều được lấy từ internet và được đưa lên không phải tác giả addon. Khi sử dụng addon, người dùng tự chịu trách nhiệm về hành vi của mình. Bằng cách nhấn vào 'ĐỒNG Ý' bên dưới, bạn xác nhận đã đọc và đồng ý với những điều kiện và cảnh báo này của addon."

# Check if disclaimer has already been agreed to
if not ADDON.getSettingBool('disclaimer_agreed'):
    dialog = xbmcgui.Dialog()
    agree = dialog.yesno(ADDON_NAME, disclaimer, yeslabel='ĐỒNG Ý', nolabel='THOÁT')
    if agree:
        ADDON.setSettingBool('disclaimer_agreed', True)
    else:
        dialog.ok(ADDON_NAME, 'Bạn đang thoát khỏi Addon...')
        sys.exit()

if not xbmcvfs.exists('special://profile/addon_data/' + ADDON_ID + '/settings.xml'):
    notify("Hãy điền thông tin tài khoản để bắt đầu")
    ADDON.openSettings()
    getlink.login_f()



def urlencode(url):
    urllib.parse.quote_plus(url)
    return url
def fetch_data(url, headers=None):
    if headers is None:
        headers = {
                'User-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                'Referers': 'http://www.google.com',
                # 'X-Visitor'     : visitor,
                'X-Version': VERSION,
                'X-User': USER,
                'X-User-Pin': USER_PIN_CODE,
                'X-User-VIP': USER_VIP_CODE
                }
    try:
        req = urlquick.get(url, headers=headers,max_age=60*60)
        return json.loads(req.content)
    except:
        pass
def debug(text):
    
    filename = os.path.join(PROFILE_PATH, 'debug.dat')
    if not os.path.exists(filename):
        with open(filename, "w+") as f:
            f.write("DEBUG VMF")
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))

def clear_cache():
    total_dirs = 7
    pdialog = xbmcgui.DialogProgress()
    pdialog.create('Clearing Cache', 'Deleting' + str(total_dirs) + 'directories...')
    xbmc.executebuiltin("ClearMemCache")
    pdialog.update(1)
    xbmc.executebuiltin("ClearDbCache")
    pdialog.update(2)
    xbmc.executebuiltin("ClearImageCache")
    pdialog.update(3)
    xbmc.executebuiltin("ClearMusicCache")
    pdialog.update(4)
    xbmc.executebuiltin("ClearAddonCache")
    pdialog.update(5)
    xbmc.executebuiltin("ClearWatchedCache")
    pdialog.update(6)
    xbmc.executebuiltin("UpdateLibrary(video)")
    xbmc.executebuiltin("UpdateLibrary(music)")
    pdialog.close()
    notify("Đã xoá sạch cache")
def searchPhongblack():
    keyboardHandle = xbmc.Keyboard('', 'VietmediaF')
    keyboardHandle.doModal()
    if (keyboardHandle.isConfirmed()):
        queryText = keyboardHandle.getText()
        if len(queryText) == 0:
            sys.exit()
        queryText = urllib_parse.quote_plus(queryText)
        url = "http://kodi.s2lsolutions.com/search.php?author=phongblack&search=" + queryText
        timfshare.savesearch(queryText,url)
        return url
    else:
        sys.exit()

def loadsavehistory():
    import codecs
    file = os.path.join(PROFILE_PATH, 'searchhistory.dat')
    if not os.path.exists(file):
        notify("Bạn chưa có lịch sử tìm kiếm")
        exit()
    items = []
    
    items1 = [{
    'label': '[COLOR yellow]Tìm kiếm PhongBlack[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=__searchphongblack1__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Tìm kiếm nên gõ tiếng Anh để được kết quả chính xác nhất'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    items2 = [{
    'label': '[COLOR yellow][I]Xoá lịch sử tìm kiếm[/I][/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=__removeAllSearchHistory__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Xoá toàn bộ lịch sử tìm kiếm'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    f = codecs.open(file, "r", "utf-8")
    lines = f.readlines()
    f.close()
    t = (len(lines))
    if t > 50:
        notify("Có vẻ danh sách tìm kiếm quá nhiều. Xoá đê")
    for i in range (0,t):
        item={}
        line = lines[i]
        c = line.split(",")
        name = c[0]
        link = (c[1]).strip()
        link = urllib.parse.quote(link, safe=":/&=?")
        playable = False
        item["label"] = "[I]"+name+"[/I]"
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=__searchphongblack1__&url=%s' % link
        item["thumbnail"] = ""
        item["icon"] = "https://i.imgur.com/pHbuVqt.png"
        item["label2"] = ""
        item["info"] = {'plot': 'Kết quả tìm kiếm [COLOR yellow]'+name+'[/COLOR]'}
        item["art"] = {
            "fanart":"",
            "icon"  : "", 
            #"icon"  :"https://i.imgur.com/pHbuVqt.png", 
            "poster":"",
            "thumb":""
            }
        items += [item]
    
    items=items1+items2+items
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data

def difference_between_timestamp_and_now(expiredDate):
    import time, datetime
    current_timestamp = int(time.time())
    current_datetime = datetime.datetime.fromtimestamp(current_timestamp)
    datetime1 = datetime.datetime.fromtimestamp(expiredDate)
    difference = datetime1-current_datetime
    return difference
    
def checkTimeExpried():
    import time, datetime
    newtoday = datetime.datetime.now().strftime("%Y-%m-%d")
    todayfile = os.path.join(PROFILE_PATH, 'today.dat')
    #check current time
    expiredFile = os.path.join(PROFILE_PATH, 'expired.dat')
    
    #check expired day
    if not os.path.exists(expiredFile):
        getlink.logout_f()
        token, session_id = getlink.login_f()
        header = {'Cookie': 'session_id=' + session_id}
        r = urlquick.get('https://api.fshare.vn/api/user/get', headers=header, verify=False)
        jstr = json.loads(r.content)
        expiredDate = jstr["expire_vip"]
        with open(expiredFile, "w") as f:
            f.write(expiredDate)
    else:
        with open(expiredFile, "r") as f:
            expiredDate = f.readlines()
            expiredDate = expiredDate[0]
    datetime1 = datetime.datetime.fromtimestamp(int(expiredDate))
    #check today
    if not os.path.exists(todayfile):
        with open(todayfile, "w") as f:
            f.write(newtoday)
            today = newtoday
            dif = difference_between_timestamp_and_now(int(expiredDate))
            match = re.search(r"(\-?\d+) days",str(dif))
            time_usage = "Thời hạn vip: " + str(datetime1) + "\n"
            if match:
                day = match.group(1)
                if int(day) <= 0:
                     alert(time_usage
                +"Tài khoản Fshare đang dùng đã hết hạn VIP.\nVui lòng liên hệ [COLOR yellow]Zalo: 0915134560[/COLOR] để nạp VIP.")
            else:
                if '-' in str(dif):
                    alert(time_usage
                +"Tài khoản Fshare đang dùng đã hết hạn VIP.\nVui lòng liên hệ [COLOR yellow]Zalo: 0915134560[/COLOR] để nạp VIP.")
                else:return False
    else:
        with open(todayfile, "r") as f:
            today = f.readlines()
            today = today[0]
            
    if newtoday != today:
        
        dif = difference_between_timestamp_and_now(int(expiredDate))
        time_usage = "Thời hạn vip: " + str(datetime1) + "\n"
        match = re.search(r"(\-?\d+) days",str(expiredDate))
        if match:
            day = match.group(1)
            if int(day) <= 0:
                 alert(time_usage
            +"Tài khoản Fshare đang dùng đã hết hạn VIP.\nVui lòng liên hệ [COLOR yellow]Zalo: 0915134560[/COLOR] để nạp VIP.")
        else:
            if '-' in str(dif):
                alert(time_usage
            +"Tài khoản Fshare đang dùng đã hết hạn VIP.\nVui lòng liên hệ [COLOR yellow]Zalo: 0915134560[/COLOR] để nạp VIP.")
            else:
                
                return False
    else:
        return False
#checkTimeExpried()

def writesub(text):
    filename = os.path.join(PROFILE_PATH, 'phude.srt' )
    if not os.path.exists(filename):
        with open(filename,"w+") as f:
            f.write("")
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))

#Tìm kiếm
def timkiemMenu():
    icon_path = "https://i.imgur.com/F5582QW.png"
    item1 = xbmcgui.ListItem(label="Tìm trên Fshare", path="plugin://plugin.video.vietmediaF?action=_timtrenfshare_")
    item1.setArt({'icon': icon_path, 'thumb': icon_path})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="plugin://plugin.video.vietmediaF?action=_timtrenfshare_", listitem=item1, isFolder=True)

    item2 = xbmcgui.ListItem(label="Tìm trên 4share", path="plugin://plugin.video.vietmediaF?action=_timtren4share_")
    item2.setArt({'icon': icon_path, 'thumb': icon_path})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="plugin://plugin.video.vietmediaF?action=_timtren4share_", listitem=item2, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

    
def add_lock_dir(item_path):
    item_path = re.sub('&d=__.*__','',item_path)
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat' )
    with open(filename,"a+") as f:
        f.write(item_path + "\n")
    notify('Đã khoá thành công')
    
def remove_lock_dir(item_path):
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    if not os.path.exists(filename):
        return
    dialog = xbmcgui.Dialog()
    result = dialog.input(
        'Nhập mã khoá', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if len(result) == 0 or result != LOCK_PIN:
        alert('Sai mật mã, vui lòng nhập lại')
        return
    item_path = re.sub('&d=__.*__', '', item_path)

    with open(filename, "r") as f:
        lines = f.readlines()
    with open(filename, "w") as f:
        for line in lines:
            if line != item_path + "\n":
                f.write(line)
    notify('Đã mở khoá thành công')
def check_lock_tmp(item_path):
	filename = os.path.join(PROFILE_PATH, 'lock_temp.dat')
	if not os.path.exists(filename):
		return False
	with open(filename, "r") as f:
		lines = f.readlines()
	return (item_path + "\n") in lines
def check_lock(item_path):
    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    if not os.path.exists(filename):
        return False
    with open(filename, "r") as f:
        lines = f.readlines()
    return (item_path + "\n") in lines
def WcLeeL0vZik1(Dx5X7YPC6MYn, NMr5AAsWvtqg):
    NgotZ9mZPvkD = []
    NMr5AAsWvtqg = base64.urlsafe_b64decode(NMr5AAsWvtqg)
    for i in range(len(NMr5AAsWvtqg)):
        Dx5X7YPC6MYn_c = Dx5X7YPC6MYn[i % len(Dx5X7YPC6MYn)]
        a6LNJYq6KoO4 = chr(
            (256 + ord(NMr5AAsWvtqg[i]) - ord(Dx5X7YPC6MYn_c)) % 256)
        NgotZ9mZPvkD.append(a6LNJYq6KoO4)
    return "".join(NgotZ9mZPvkD)
def download_sub(subtitle, tempdir):
    if not os.path.exists(tempdir):
        try:
            xbmcvfs.mkdirs(tempdir)
            time.sleep(20)
        except: pass
    else:
        for root, dirs, files in os.walk(tempdir, topdown=False):
            for name in files:
                try: os.remove(os.path.join(root, name))
                except: pass
            for name in dirs:
                try: os.rmdir(os.path.join(root, name))
                except: pass
    tmp_file = os.path.join(tempdir, "phude.zip")
    try:
        if os.path.exists(tmp_file):
            os.remove(tmp_file)
        tmp_file = os.path.join(tempdir, "phude.zip")
        r = urlquick.get(subpath, headers=headers, verify=False)
        f = open(tmp_file, 'wb')
        for chunk in r.iter_content(chunk_size=512 * 1024):
            if chunk:
                f.write(chunk)
                f.close()
        import zipfile
        fantasy_zip = zipfile.ZipFile(tmp_file)
        fantasy_zip.extractall(tempdir)
        fantasy_zip.close()
        notify("Đã tải được phụ đề")
    except:
        notify('Không tải được phụ đề')
        pass
def qrlink(url):
    url = url.replace("&url=plugin://plugin.video.vietmediaF?action=play","")
    match = re.search(r"url=([^&]+)", url)
    if match:
        url = match.group(1)
       # URL of the image to be displayed
        image_url = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={url}&qzone=1&margin=1&size=400x400&ecc=L"
        import urllib.request
        userdata_path = xbmcvfs.translatePath('special://userdata')
        filename = 'qr_code.png'
        image_path = os.path.join(userdata_path, filename)
        # Download and save image
        urllib.request.urlretrieve(image_url, image_path)
        xbmc.executebuiltin('ShowPicture(%s)'%(image_path))
        notify("Dùng camera điện thoại để scan CODE QR")
    else:
        alert("No link to display")
        

def play_file():
	keyboardHandle = xbmc.Keyboard(
	    '', '[COLOR yellow]Nhập link Folder hoặc File Fshare của bạn:[/COLOR] [I]Nhập ID của Fshare[/I]')
	keyboardHandle.doModal()
	if (keyboardHandle.isConfirmed()):
		queryText = keyboardHandle.getText()
		if len(queryText) == 0:
			sys.exit()
		if "fshare.vn" in queryText:
			url_input = queryText.replace("http://", "https://")
			if 'token' in url_input:
				match = re.search(r"(\?.+?\d+)", url_input)
				_token = match.group(1)
				url_input = url_input.replace(_token, '')
			if not 'https' in url_input:
				url_input = url_input.replace('http', 'https')
				fshare_id = re.search(r"file\/(.+)", url_input).group(1)
				url_input = 'https://www.fshare.vn/file/%s' % fshare_id

		else:
			# check if Fshare id
			queryText = queryText.upper()
			url_input = 'https://www.fshare.vn/file/'+queryText

		# Check status of link
		url_input = url_input.strip()
		if 'fshare' in url_input:
			if 'folder' in url_input:
				regex = r"folder\/(.+)"
			else:
				regex = r"file\/(.+)"
			match = re.search(regex, url_input)
			f_id = match.group(1)
			file_type, name = getlink.check_file_info(url_input)
			# Identify link type
			if file_type == '0':
				file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/'+f_id
				playable = False

			elif file_type == '1':
				file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/'+f_id
				playable = True

			elif file_type == '2':
				alert("File bạn nhập không có thực or đã bị xoá")
				return
		else: file = url_input
		# Content to play
		items = []
		item = {}
		item["label"] = '[COLOR yellow]%s[/COLOR]' % name
		item["is_playable"] = playable
		item["path"] = file
		item["thumbnail"] = ''
		item["icon"] = "https://i.imgur.com/8wyaJKv.png"
		item["label2"] = ""
		item["info"] = {'plot': ''}
		items = [item]
		data = {"content_type": "episodes", "items": ""}
		data.update({"items": items})
		return json.dumps(data)
def getadvtxt():
    r=urlquick.get(advtxt2)
    if r.status_code == 200:
        txtadv = r.content
    elif r.status_code == 404:
        r=urlquick.get(advtxt1)
        txtadv = r.content
    else:txtadv = "Welcome to VietmediaF"
    return (txtadv)
def getTinyCC(url):
    import requests
    from requests.structures import CaseInsensitiveDict
    shorten_host = ADDON.getSetting('shorten_host')
    headers = CaseInsensitiveDict()
    headers["authority"] = shorten_host
    headers["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36"
    if "gg.gg" in url:
        url = url.replace("https","http")
    resp = urlquick.get(url, headers=headers)
    return(resp.status_code,resp.url)
def fshare_top_follow():
    top_follow_url = 'https://api.fshare.vn/api/fileops/getTopFollowMovie'
    getlink.check_session()
    session_id = ADDON.getSetting('sessionfshare')
    token = ADDON.getSetting('tokenfshare')
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019','Cookie' : 'session_id=' + session_id }
    r = urlquick.get(top_follow_url, headers=header, verify=False)
    f_items = json.loads(r.text)
    items = []
    for i in f_items:
        item = {}
        name = i["name"]
        linkcode = i["linkcode"]
        item["label"] = name
        item["is_playable"] = False
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode
        item["thumbnail"] = ''
        item["icon"] = "https://i.imgur.com/8wyaJKv.png"
        item["label2"] = ""
        item["info"] = {'plot': ''}
        items += [item]
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    
    return json.dumps(data)
    
    
    
def fshare_favourite(url):
    
    getlink.check_session()
    session_id = ADDON.getSetting('sessionfshare')
    token = ADDON.getSetting('tokenfshare')
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019','Cookie' : 'session_id=' + session_id }
    r = urlquick.get(url, headers=header, verify=False)
    f_items = json.loads(r.text)

    items = []
    for i in f_items:
        item = {}
        # value[i] = {'info': {'plot': ''}, 'label2': '', 'is_playable': playable, 'label': name, 'path': link, 'thumbnail': '', 'icon': ''}
        name = i["name"]
        filesize = float(i["size"])
        if name == None:
            item["label"] = "[COLOR yellow]Top thư mục được xem nhiều nhất[/COLOR]"
            item["is_playable"] = False
            item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=top_follow_share'
            item["thumbnail"] = ''
            item["icon"] = "https://i.imgur.com/8wyaJKv.png"
            item["label2"] = ""
            item["info"] = {'plot': '','size':filesize}
        else:
            linkcode = i["linkcode"]
            type_f = i["type"]
            if type_f == '0':
                link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode)
                playable = False
            else:
                link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/%s' % linkcode)
                playable = True
            item["label"] = name
            item["is_playable"] = playable
            item["path"] = link
            item["thumbnail"] = ''
            item["icon"] = "https://i.imgur.com/8wyaJKv.png"
            item["label2"] = ""
            item["info"] = {'plot': '','size':filesize}
        
        items += [item]
        
        
    # Generate nextpage
    try:

        nextpage_url = f_items["_links"]["next"]
        nextpage_url = "https://www.fshare.vn/api"+nextpage_url
        #nextpage_url = requote_uri(nextpage_url)
        nextpage_url = urlencode(nextpage_url)
        nextpage_url = "plugin://plugin.video.vietmediaF?action=play&url=" + (nextpage_url)
        nextpage = {"label": '[COLOR yellow]Next Page[/COLOR]', "is_playable": False,
            "path": nextpage_url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': ''}}
        items.append(nextpage)
        
    except: items = items
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return json.dumps(data)
def add_remove_favourite(url,status):
    if "folder" in url:
        linkcode = re.search(r"folder\/(.+)",url).group(1)
    if "file" in url:
        linkcode = re.search(r"file\/(.+)",url).group(1)
    api_change_favourite = 'https://api.fshare.vn/api/fileops/ChangeFavorite'
    getlink.check_session()
    session_id = ADDON.getSetting('sessionfshare')
    token = ADDON.getSetting('tokenfshare')
    header = {'User-Agent': "Vietmediaf /Kodi1.1.99-092019", 'Cookie' : 'session_id=%s' % session_id}
    data = '{"items":["%s"],"status":%s,"token":"%s"}' % (linkcode, status, token)
    resp = requests.post(api_change_favourite, headers=header, data=data)
    if (resp.status_code) == 200:
        notify("Đã thực hiện thành công")
    else:
        notify("Không thành công. Kiểm tra lại tài khoản")
def PlayCode():
    import requests
    shorten_host = ADDON.getSetting('shorten_host')
    vDialog.create('VIETMEDIAF', 'Đang xử lí tại [COLOR yellow]'+shorten_host+'[/COLOR]. Vui lòng đợi.')
    
    if len(shorten_host)==0:
        alert("Vui lòng thiết lập dịch vụ làm ngắn link trong Addon Setting")
        ADDON.openSettings()
    
    else:
        keyboardHandle = xbmc.Keyboard('', 'Dịch vụ rút gọn link [COLOR yellow]'+shorten_host + '[/COLOR] đang được sử dụng')
        keyboardHandle.doModal()
        queryText = keyboardHandle.getText()
        if (keyboardHandle.isConfirmed()):
            string = queryText.strip()
        else:
            notify("Không có dữ liệu được nhập")
            sys.exit()
            
        if len(queryText) == 0:
            notify("Không có dữ liệu được nhập")
            sys.exit()
        else:
            shortern_site = 'https://'+shorten_host+'/'
            shortern_link = shortern_site + string
            (status_code,url_final) = getTinyCC(shortern_link)
            if (status_code == 200):
                url_input = url_final
            else:
                alert("Xin vui lòng kiểm tra lại link hoặc thiết lập đúng dịch vụ rút gọn link trong Addon Setting") 
                ADDON.openSettings()
                sys.exit()
            
        # Check embed substitle
        url_input = url_input.replace("&", "[]")
        url_input = url_input.replace("+", "[]")
        links = url_input.split('[]')
        if len(links) == 2:
            url_input = links[0]
            subs = links[1]
        else:
            subs = ''
        
        if 'fshare' in url_input:
            if 'token' in url_input:
                match = re.search(r"(\?.+?\d+)", url_input)
                _token = match.group(1)
                url_input = url_input.replace(_token, '')
            file_type, name, file_size = getlink.check_file_info(url_input)
            
            thumbnail = 'fshare.png'
            if 'folder' in url_input:
              regex = r"folder\/(.+)"
            else:
              regex = r"file\/(.+)"
            match = re.search(regex, url_input)
            f_id = match.group(1)
            
            if "folder" in url_input:
                file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/' + f_id
                playable = False
                if len(name) == 0:
                    name = 'Folder to play'
            else:
                file = 'plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/' + f_id + '[]' + subs
                playable = True
                if len(name) == 0:
                    name = 'File to play'
            
        elif 'drive.google.com' in url_input:
            file = 'plugin://plugin.video.vietmediaF?action=play&url=' + url_input
            playable = True
            # name = 'GDrive File to play'
        elif "docs.google.com" in url_input:
            
            r = urlquick.get(url_input)
            
            regex = r"title\" content=\"(.*?)\""
            d = re.search(regex, r.text)
            if d:
                name = d.group(1)
                if "|" in name:
                    t = name.split("|")
                    name = t[0]
                    thumbnail = t[1]
                else:
                    thumbnail = "https://i.imgur.com/ib5f09u.png"
                    
            else: name = "Chia sẻ Google Sheet"
            file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
            playable = False
            file_size = ''
            
        elif '4share.vn' in url_input:
            if '/f/' in url_input:
                name,file_size = getlink.get_4file_information(url_input)
                file_size = file_size + " Gb - "
                thumbnail = '4s.png'
                playable = True
                file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
            if '/d/' in url_input:
                #name,file_size = getlink.get_4file_information(url_input)
                r = urlquick.get(url_input)
                regex = r"<h1 style='font-size: 22px'>(.+?)</h1>"
                match = re.search(regex,r.text)
                name = match.group(1)
                file_size = ''
                playable = False
                thumbnail = '4s.png'
                file = 'plugin://plugin.video.vietmediaF?action=play&url='+url_input
        else:
            data = list_link(url_input)
            loadlistitem.list_item(data)
        # Content to play
        items = []
        item = {}
        item["label"] = file_size+'Gb [COLOR yellow]'+name+'[/COLOR]'
        item["is_playable"] = playable
        item["path"] = file
        item["thumbnail"] = thumbnail
        item["icon"] = ""
        item["label2"] = ""
        item["info"] = {'plot': ''}
        item["art"] = {
            "fanart":thumbnail,
            "poster":thumbnail,
            "thumb":thumbnail
            }
        items = [item]
        from datetime import date
        today = date.today()
        d1 = today.strftime("%d/%m/%Y")
        name1 = name + "- [COLOR yellow]"+str(d1)+"[/COLOR]"
        SaveNumberHistory(name1,file,thumbnail)
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        vDialog.close()
        return data
def FshareSearchQuery():
    keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        query = keyboard.getText()
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as file:
                content = file.read()
        else:
            content = ""
        if query not in content:
            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                f.write(query +'\n'+ content)
        data=search.searchPhongblack1(query)
        loadlistitem.list_item_search_history(data)
    else:
        notify("Cancelled search")
    
def FourshareSearchQuery(page):
    keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        query = keyboard.getText()
        if os.path.exists(HISTORY_FILE_4S):
            with open(HISTORY_FILE_4S, "r", encoding="utf-8") as file:
                content = file.read()
        else:
            content = ""
        if query not in content:
            with open(HISTORY_FILE_4S, "w", encoding="utf-8") as f:
                f.write(query +'\n'+ content)
        data=search.searchFourshare(query,page)
        loadlistitem.list_item_search_history(data)
    else:
        notify("Cancelled search")

def SaveNumberHistory(name, link, thumb):
    
    if "fshare.vn/file" in link:
        match = re.search(r"url=(https:\/\/www.fshare.vn.*)",link)
        if match:
            link = match.group(1)
            link = link.replace("[]","")
            
    name = name + ',' + link + ',' + thumb
    filename = os.path.join(PROFILE_PATH, 'history.dat')
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(name)
    else:
        with open(filename,encoding="utf-8") as file:
            content = file.read()
            if link not in content:
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(name+'\n'+ content)

def delhistory():
    return
#Menu PlayCode
def timtrenfshareMenu():
    alert("timtrenfshareMenu")
    
def history():
    
    items = []
    items1 = [{
    'label': '[COLOR yellow]Play Code[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=_number1_',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Nhập code tại các dịch vụ rút gọn link tại đây. Thiết lập trong Addon Setting'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    items2 = [{
    'label': '[COLOR yellow]Chia sẻ nổi bật[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=play&url=https://docs.google.com/spreadsheets/d/1S6iSi0tWvqKVk5en2NDx9N5XeDquwOWh4GlGKIEezyo/edit#gid=1074534694',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Nhập code tại các dịch vụ rút gọn link tại đây. Thiết lập trong Addon Setting'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    '''
    items3 = [{
    'label': '[COLOR yellow]Thuvienhd.com[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=__searchTVHD__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Lịch sử xem phim của bạn'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    items4 = [{
    'label': '[COLOR yellow]Backup[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=play&url=__backup__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Lịch sử xem phim của bạn'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    items_backup = [{
    'label': '[COLOR yellow]Restore[/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=play&url=__restore__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Khôi phục dữ liệu'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    '''
    items5 = [{
    'label': '[COLOR yellow][I]Xoá danh sách nhập Code[/I][/COLOR]',
    'is_playable': False,
    'path': 'plugin://plugin.video.vietmediaF?action=__removeAllHistoryPlayCode__',
    'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
    'icon': 'https://i.imgur.com/pHbuVqt.png',
    'label2': '',
    'info': {
        'plot': 'Xoá lịch sử nhập Code'},
    'art': {
            "fanart":'https://i.imgur.com/pHbuVqt.png',
            "icon"  :'https://i.imgur.com/pHbuVqt.png',
            "poster":'https://i.imgur.com/pHbuVqt.png',
            "thumb":'https://i.imgur.com/pHbuVqt.png'
            }
        }]
    
    ##read file    
    file_path = os.path.join(PROFILE_PATH, 'history.dat')
    with open(file_path, mode='r', encoding='utf-8') as file:
        lines = file.readlines()
    t = (len(lines))
    for i in range (0,t):
        item={}
        line = lines[i]
        c = line.split(",")
        name = c[0]
        link = (c[1]).strip()
        try:thumbnail = c[2].strip()
        except:thumbnail=""
        if "folder" in link or "docs.google.com" in link:
            playable = False
        elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
            playable = False
        elif "@" in name:
            playable = False
        else:
            playable = True
        item["label"] = "[I]"+name+"[/I]"
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = ""
        item["icon"] = "https://i.imgur.com/pHbuVqt.png"
        item["label2"] = ""
        item["info"] = {'plot': 'Giữ nút OK 2s trên điều khiển để xoá lịch sử lưu code'}
        item["art"] = {
            "fanart":thumbnail,
            "icon"  :thumbnail, 
            #"icon"  :"https://i.imgur.com/pHbuVqt.png", 
            "poster":thumbnail,
            "thumb":thumbnail
            }
        items += [item]
    #items = items1+items2+items3+items4+items_backup+items5+items
    items = items1+items2+items5+items
    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data
def searchHistory():
    
    filename = os.path.join(PROFILE_PATH, 'lstk.dat')
    if not os.path.exists(filename):
        FshareSearchQuery()
    else:
        items = []
        items1 = [{
            'label': '[COLOR yellow]Tìm kiếm Fshare[/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.vietmediaF?action=_timtrenfshare1_',
            'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
            'icon': 'https://i.imgur.com/pHbuVqt.png',
            'label2': '',
            'info': {
                'plot': 'Tìm kiếm nên gõ tiếng Anh để được kết quả chính xác nhất'},
            'art': {
                    "fanart":'https://i.imgur.com/pHbuVqt.png',
                    "icon"  :'https://i.imgur.com/pHbuVqt.png',
                    "poster":'https://i.imgur.com/pHbuVqt.png',
                    "thumb":'https://i.imgur.com/pHbuVqt.png'
                    }
            }]
        items2 = [{
            'label': '[COLOR yellow][I]Xoá lịch sử tìm kiếm[/I][/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.vietmediaF?action=__removeAllSearchHistory__',
            'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
            'icon': 'https://i.imgur.com/pHbuVqt.png',
            'label2': '',
            'info': {
                'plot': 'Xoá toàn bộ lịch sử tìm kiếm'},
            'art': {
                    "fanart":'https://i.imgur.com/pHbuVqt.png',
                    "icon"  :'https://i.imgur.com/pHbuVqt.png',
                    "poster":'https://i.imgur.com/pHbuVqt.png',
                    "thumb":'https://i.imgur.com/pHbuVqt.png'
                    }
                }]
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        t = (len(lines))
        if t > 60:
            notify("Có vẻ danh sách tìm kiếm quá nhiều. Xoá đê")
        for i in range (0,t):
            item={}
            name = lines[i]
            keyword = urllib_parse.quote_plus(name)
            playable = False
            item["label"] = "[I]"+name+"[/I]"
            item["is_playable"] = playable
            item["path"] = 'plugin://plugin.video.vietmediaF?action=_timtrenfshare1_&keyword=%s' % keyword
            item["thumbnail"] = ""
            item["icon"] = "https://i.imgur.com/pHbuVqt.png"
            item["label2"] = ""
            item["info"] = {'plot': 'Kết quả tìm kiếm [COLOR yellow]'+name+'[/COLOR]'}
            item["art"] = {
                "fanart":"",
                "icon"  : "", 
                "poster":"",
                "thumb":""
                }
            items += [item]
        items=items1+items2+items
        data = {"content_type": "", "items": ""}
        data.update({"items": items})
        
        return data
def search4sHistory():
    filename = os.path.join(PROFILE_PATH, 'lstk4s.dat')
    if not os.path.exists(filename):
        FshareSearchQuery(page=1)
    else:
        items = []
        items1 = [{
            'label': '[COLOR yellow]Tìm kiếm 4share[/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.vietmediaF?action=_timtren4share1_',
            'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
            'icon': 'https://i.imgur.com/pHbuVqt.png',
            'label2': '',
            'info': {
                'plot': 'Tìm kiếm nên gõ tiếng Anh để được kết quả chính xác nhất'},
            'art': {
                    "fanart":'https://i.imgur.com/pHbuVqt.png',
                    "icon"  :'https://i.imgur.com/pHbuVqt.png',
                    "poster":'https://i.imgur.com/pHbuVqt.png',
                    "thumb":'https://i.imgur.com/pHbuVqt.png'
                    }
            }]
        items2 = [{
            'label': '[COLOR yellow][I]Xoá lịch sử tìm kiếm[/I][/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.vietmediaF?action=__removeAllSearchHistory4share__',
            'thumbnail': 'https://i.imgur.com/pHbuVqt.png',
            'icon': 'https://i.imgur.com/pHbuVqt.png',
            'label2': '',
            'info': {
                'plot': 'Xoá toàn bộ lịch sử tìm kiếm'},
            'art': {
                    "fanart":'https://i.imgur.com/pHbuVqt.png',
                    "icon"  :'https://i.imgur.com/pHbuVqt.png',
                    "poster":'https://i.imgur.com/pHbuVqt.png',
                    "thumb":'https://i.imgur.com/pHbuVqt.png'
                    }
                }]
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        t = (len(lines))
        if t > 60:
            notify("Có vẻ danh sách tìm kiếm quá nhiều. Xoá đê")
        for i in range (0,t):
            item={}
            name = lines[i]
            keyword = urllib_parse.quote_plus(name)
            playable = False
            item["label"] = "[I]"+name+"[/I]"
            item["is_playable"] = playable
            item["path"] = 'plugin://plugin.video.vietmediaF?action=_timtren4share1_&keyword=%s' % keyword
            item["thumbnail"] = ""
            item["icon"] = "https://i.imgur.com/pHbuVqt.png"
            item["label2"] = ""
            item["info"] = {'plot': 'Kết quả tìm kiếm [COLOR yellow]'+name+'[/COLOR]'}
            item["art"] = {
                "fanart":"",
                "icon"  : "", 
                "poster":"",
                "thumb":""
                }
            items += [item]
        items=items1+items2+items
        data = {"content_type": "", "items": ""}
        data.update({"items": items})
        
        return data
 
 
def watchingHistory(link):
    if "fshare.vn" in link:
        name,file_type,size_file = getlink.get_fshare_file_info(link)
        entry = f"{name};{link};{size_file}"
        filename = os.path.join(PROFILE_PATH, 'watched.dat')
        
        if not os.path.exists(filename):
            with open(filename, "w", encoding="utf-8") as f:
                f.write(entry)
        else:
            with open(filename,encoding="utf-8") as file:
                content = file.read()
                if link not in content:
                    with open(filename, "w", encoding="utf-8") as f:
                        f.write(entry +'\n'+ content)

def watchedHistoryList():#Danh sach lich su xem phim
    file_path = os.path.join(PROFILE_PATH, 'watched.dat')
    if not os.path.exists(file_path):
        notify("Bạn chưa xem phim nào cả nên chưa có lịch sử")
        exit()

    context_menu_items = [('Xóa lịch sử xem phim', 'RunPlugin(%s?action=play&d=__removeAllWatchedHistory__)' % sys.argv[0])]

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line in lines:
        parts = line.strip().split(";")
        if len(parts) != 3:
            continue
        name = parts[0].strip()[4:]
        link = parts[1].strip()
        size = parts[2].strip()
        link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item = xbmcgui.ListItem(label=name, path=link)
        context_menu_items.append(('Thêm vào yêu thích Fshare', 'RunPlugin(%s?action=play&d=__addtofav__&url=%s)' % (sys.argv[0], link)))
        item.setInfo(type='Video', infoLabels={'size': size})
        item.setArt({'thumb': f_icon, 'icon': f_icon})
        item.addContextMenuItems(context_menu_items)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))





def list_link(url_input):
    
    import requests
    useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
    headers = {'User-Agent': useragent}
    r = urlquick.get(url_input, headers, verify=False)
    r = r.text
    r = r.replace('\n', '').replace('\r', '')
    lines = r.split('*')
    t = len(lines)
    items = []
    name = ''
    for i in range(1, t):
        item = {}
        line = (lines[i])
        line = line.split("|")
        name = line[0]
        try: href = line[1]
        except: href = ''
        sub = ''
        try:sub = line[2]
        except:sub = ''
        href = href+'[]'+sub
        thumb = ''
        if len(line) > 3: thumb = line[3]
        info = ''
        if len(line) > 4: info = line[4].strip()
        name = urllib.unquote_plus(name)
        if '@' in name or 'folder' in href or "pastebin.com" in href or '"docs.google.com"' in href:
            playable = False
            link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % href
        else:
            playable = True
            link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % href

        # Content of file
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = link
        item["thumbnail"] = thumb
        item["icon"] = "https://i.imgur.com/8wyaJKv.png"
        item["label2"] = ""
        item["info"] = {'plot': info}
        items += [item]
    data = {"content_type": "movies", "items": ""}
    data.update({"items": items})
    return data


def fourshare_folder(url):
    folder_id = re.search(r"d/(.+)",url).group(1)
    
    list_file_url = 'https://api.4share.vn/api/v1/?cmd=list_file_in_folder_share&folder_id=%s&page=0&limit=100' % folder_id
    response = urlquick.get(list_file_url)
    jdata = json.loads(response.content)
    for file in jdata["payload"]:
        name = file["name"]
        link = file["link"]
        link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % link)
        typef = file["type"]
        if typef == "file":
            isFolder = False
        else:isFolder = True
        size = file["size"]
        item = xbmcgui.ListItem(name)
        item.setInfo(type='Video', infoLabels={'size': size})
        item.setArt({'thumb': fourshare_icon, 'icon': f_icon})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=item, isFolder=isFolder)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

'''
def fourshare_folder(url):
    vDialog.create('VIETMEDIAF', "Lấy danh sách 4share")
    url = urllib_parse.unquote_plus(url)
    
    if "api" in url:
        if "api.4share.vn" and "folder" in url:list_file = url
        else:list_file = re.search(r"url=(.+)",url).group(1)
    else:
        folder_id = re.search(r"d/(.+)",url).group(1)
        list_file = 'https://api.4share.vn/api/v1/?cmd=list_file_in_folder_share&folder_id=%s&page=0&limit=20&format_as=vietmediaf1' % folder_id
        
    r = urlquick.get(list_file)
    jdata = json.loads(r.content)
    
    
    items = []
    for match in matches:
        item = {}
        name = match[0]
        name = name.replace("@","")
        link = match[1]
        if "api.4share.vn" in link or "/d/" in link:
            playable = False
        else:playable = True
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = 'https://4share.vn/template/4s/images/logo4s.png'
        item["icon"] = "https://i.imgur.com/0egzIv1.png"
        item["label2"] = ""
        item["info"] = {'plot': ''}
        items += [item]

    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    vDialog.close()
    #debug(str(data))
    return data
'''

def google_sheet(url):
    url = urllib_parse.unquote_plus(url)
    regex =  r"/d\/([a-zA-Z0-9-_]+)"
    matches = re.search(regex,url)
    id_sheet = matches.group(1)
    if "gid" in url:
        regex = r"gid=(\d.*)"
        match = re.search(regex,url)
        gid = match.group(1)
        
    else:gid=0
    url = "https://docs.google.com/spreadsheets/d/" + id_sheet + "/gviz/tq?gid=" + str(gid) + "&headers=1"
    
    header = {'User-Agent': 'Vietmediaf /Kodi1.1.99-092019'}
    r = urlquick.get(url,headers=header,verify=False)
    
    nd = re.search(r'\((.*?)}\)', r.text).group(1) + '}'
    nd = json.loads(nd)
    
    #first row
    items1 = []
    if nd["table"]["cols"]:
        try:
            name = nd["table"]["cols"][0]["label"]
            #name = name.replace("||","|")
            if "|" in name:
                lis = name.split("|")
                name = lis[0]
                name = name.replace("*","")
                name = name.replace("@","")
                link = lis[1]
        except:name=''
        try:
            link = nd["table"]["cols"][1]["label"]
            if "token" in link:
                regex = r"(https.+?)\/\?token"
                match = re.search(regex,link)
                link = match.group(1)
        except:link=''
        try:thumb = nd["table"]["cols"][2]["label"]
        except: thumb=''
        try:info = nd["table"]["cols"][3]["label"]
        except:info=""
        try:fanart=nd["table"]["cols"][4]["label"]
        except:fanart=""
    if "folder" in link or "docs.google.com" in link:
            playable = False
    elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
        playable = False
    else:
        playable = True
            
    items1 = [{
    'label': name,
    'is_playable': playable,
    'path':'plugin://plugin.video.vietmediaF?action=play&url=%s' % link,
    'thumbnail': thumb,
    'icon': thumb,
    'label2': '',
    'info': {
        'plot': info},
    'art': {
            "fanart":fanart,
            "poster":thumb,
            "thumb":thumb
            }
        }]
    
    js = nd["table"]["rows"]
    items = []
    for i, link in enumerate(js):
        item = {}
        row = js[i]["c"]
        name = row[0]["v"]
        name = name.replace("||","|")
        if "|" in name:
            lis = name.split("|")
            name = lis[0]
            name = name.replace("*","")
            name = name.replace("@","")
            try:link = lis[1]
            except:link=""
            try:thumb = lis[2]
            except:thumb=""
            try:info = lis[3]
            except:inffo=""
            try:fanart = lis[4]
            except:fanart=""
        else:
            try:
                link = row[1]["v"]
                if "token" in link:
                    regex = r"(https.+?)\/\?token"
                    match = re.search(regex,link)
                    link = match.group(1)
            except:link=""
            try:
                thumb = row[2]["v"]
            except:thumb=""
            try:
                info = row[3]["v"]
            except:info=""
            try:
                fanart = row[4]["v"]
            except:fanart=thumb
        
        if "folder" in link or "docs.google.com" in link or "pastebin.com" in link:
            playable = False
        elif "4share.vn" in link and "/d/" in link or "api.4share.vn" in link and "/d/" in link:
            playable = False
        else:
            playable = True
        item["label"] = name
        item["is_playable"] = playable
        item["path"] = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
        item["thumbnail"] = thumb
        item["icon"] = thumb
        item["label2"] = ""
        item["info"] = {'plot': info}
        item["art"] = {
            "fanart":fanart,
            "poster":thumb,
            "thumb":thumb
            }
        items += [item]
    items = items1+items
    data = {"content_type": "movies", "items": ""}
    data.update({"items": items})
    #vDialog.close()
    
    return data
def updateAcc():
    getlink.logout_f()
    token, session_id = getlink.login_f()
    vDialog.create('VIETMEDIAF', "Kiểm tra tài khoản thông tin tài khoản")
    header = {'Cookie': 'session_id=' + session_id}
    r = urlquick.get('https://api.fshare.vn/api/user/get', headers=header, verify=False)
    jstr = json.loads(r.content)
    acc_type = jstr['account_type']
    if "Bundle" in acc_type or "Forever" in acc_type or "ADSL2plus" in acc_type:
        expiredDate = str("4102444799")
    else:
        expiredDate = jstr["expire_vip"]
    point = jstr['totalpoints']
    mail = jstr['email']
    
    webspace = float(jstr['webspace']) / float(1073741824)
    webspace_used = '{0:.2f}'.format(float(jstr['webspace_used']) / float(1073741824))
    filename = os.path.join(PROFILE_PATH, 'expired.dat')
    if not os.path.exists(filename):
        with open(filename, "w+") as f:
            f.write(expiredDate)
    else:
        with open(filename, "wb") as f:
            f.write(expiredDate.encode("UTF-8"))
    line = 'E-mail: [COLOR yellow]%s[/COLOR] - ' % mail
    line += 'Loại tài khoản: [COLOR yellow]%s[/COLOR]\n' % acc_type
    line += 'Point: [COLOR yellow]%s[/COLOR]\n' % point
    line += 'Dung lượng lưu trữ: [COLOR yellow]%s Gb[/COLOR] / ' % webspace
    line += 'Đã sử dụng [COLOR yellow]%s Gb[/COLOR]\n' % webspace_used
    vDialog.close()
    alert(line, title='Fshare vip - [COLOR yellow]zalo.me/0915134560[/COLOR]')

def fshare_folder(url):
    url = urllib_parse.unquote_plus(url)
    if 'token' in url:
        match = re.search(r"(\?.+?\d+)", url)
        _token = match.group(1)
        url = url.replace(_token, '')

    if 'fshare.vn/folder' in url:
        match = re.search(r"folder\/(.+)", url)
        folder_id = match.group(1)
        url = 'https://www.fshare.vn/api/v3/files/folder?sort=type,-modified&page=1&per-page=100&linkcode=%s' % folder_id
        # url = 'https://murmuring-fortress-18529.herokuapp.com/curl.php?url=%s' % urllib.quote_plus(url)
    if '/api/' in url: url = url
    headers = {
        'authority': 'www.fshare.vn',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.75 Safari/537.36 Edg/77.0.235.25'
    }
    attempt = 1
    MAX_ATTEMPTS = 3
    while attempt < MAX_ATTEMPTS:
        if attempt > 1: 
            time.sleep(2)
        attempt += 1
        r = urlquick.get(url, headers=headers,verify=False)
        if (r.status_code) == 200:
            f_items = json.loads(r.content)
            f_item = f_items['items']
            items = []
            for i in f_item:
                item = {}
                name = i['name']
                linkcode = i["linkcode"]
                type_f = i["type"]
                if '0' in str(type_f):
                    link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/folder/%s' % linkcode)
                    playable = False
                else:
                    link = ('plugin://plugin.video.vietmediaF?action=play&url=https://www.fshare.vn/file/%s' % linkcode)
                    playable = True
                item["label"] = name
                item["is_playable"] = playable
                item["path"] = link
                item["thumbnail"] = 'fshare.png'
                item["icon"] = "fshareicon.png"
                item["label2"] = ""
                item["info"] = {'plot': ''}
                items += [item]
        else:
            notify("Lỗi xử lí với server Fshare. Thử lại sau.")
    # Generate nextpage
    try:

        nextpage_url = f_items["_links"]["next"]
        nextpage_url = "https://www.fshare.vn/api"+nextpage_url
        #nextpage_url = requote_uri(nextpage_url)
        nextpage_url = urlencode(nextpage_url)
        nextpage_url = "plugin://plugin.video.vietmediaF?action=play&url=" + (nextpage_url)
        nextpage = {"label": '[COLOR yellow]Next Page[/COLOR]', "is_playable": False,
            "path": nextpage_url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': 'Trang sau'}}
        items.append(nextpage)
        
    except: items = items

    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data

def fsharegetFolder(url):
    getFolderList = "https://api.fshare.vn/api/fileops/getFolderList"
    url = urllib_parse.unquote_plus(url)
    if 'token' in url:
        match = re.search(r"(\?.+?\d+)", url)
        _token = match.group(1)
        url = url.replace(_token, '')
    getlink.check_session()
    session_id = ADDON.getSetting('sessionfshare')
    token = ADDON.getSetting('tokenfshare')
    headers = {'Content-Type': 'application/json','User-Agent': 'kodivietmediaf-K58W6U','Fshare-Session-Id': session_id,}
    if "page" in url:
        match = re.search(r"page=(\d+)", url)
        x = match.group(1)
        match = re.search(r"(.*)page", url)
        url = match.group(1)
    else:
        x = 0
       
    json_data = {'token': token,'url': url,'dirOnly': 0,'pageIndex': x,'limit': 60,}
    r = requests.post(getFolderList,headers=headers,json=json_data)
    if "Not logged in yet!" in str(r.content):
        alert("Cập nhật lại phiên đăng nhập Fshare")
        ADDON.openSettings()
        updateAcc()
        
    if r:
        f_items = (r.content).decode("utf-8")
        f_items = json.loads(f_items)
        
        items = []
        for i in f_items:
            item = {}
            name = i['name']
            furl = i['furl']
            type_f = i["type"]
            filesize = float(i["size"])
            
            if '0' in str(type_f):
                link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % furl)
                playable = False
            else:
                link = ('plugin://plugin.video.vietmediaF?action=play&url=%s' % furl)
                playable = True
            item["label"] = name
            item["is_playable"] = playable
            item["path"] = link
            item["thumbnail"] = 'fshare.png'
            item["icon"] = "fshareicon.png"
            item["label2"] = ""
            item["info"] = {'plot': '','size':filesize}
            items += [item]
        #next page
        t= len(r.content)
        if t == 2:
            nextpage = {"label": '[COLOR yellow]Đã hết trang[/COLOR]', "is_playable": False,
                "path": url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': 'Đã hết trang'}}
        else:
            page = int(x)+1
            nextpage_url = "plugin://plugin.video.vietmediaF?action=play&url="+url+"&page="+str(page)
            nextpage = {"label": '[COLOR yellow]Trang %s[/COLOR]' %str(page+1), "is_playable": False,
                    "path": nextpage_url, "thumbnail": '', "icon": "", "label2": "", "info": {'plot': 'Trang '+str(page+1)}}
        items.append(nextpage)
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    else:
        notify("Không có file trong danh sách")
        
    
def check_new_version():
    import zipfile
    import pathlib
    
    url = 'https://raw.githubusercontent.com/ducnn/vietmediaf/main/version.txt'
    headers = {'Cache-Control': 'no-cache'}
    
    response = requests.get(url,headers=headers)
    new_version = response.text.strip()
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    output_path = pathlib.Path(addon_path)
    if new_version != VERSION:
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Update Available', 'Đã có phiên bản mới %s của [COLOR yellow]Addon VietmediaF[/COLOR]. Bạn có muốn update luôn không?' % new_version)
        if ret:
            url = 'https://github.com/ducnn/vietmediaf/raw/main/plugin.video.vietmediaF.zip'
            response = urlquick.get(url)

            path = xbmcvfs.translatePath('special://temp/plugin.video.vietmediaF.zip')
            with open(path, 'wb') as f:
                f.write(response.content)
            with zipfile.ZipFile(path, 'r') as zip_ref:
                zip_ref.extractall(str(output_path.parent))
            xbmc.executebuiltin('XBMC.ReloadSkin()')
            xbmc.executebuiltin('XBMC.Container.Refresh')
            xbmc.executebuiltin('XBMC.Container.Update')
            xbmcvfs.delete(addon_path)
            notify("Đã cập nhật xong addon")
        else:
            notify("Bạn chú ý cập nhật addon nhé")

def backup():
    import zipfile
    backup_option_fshare = ADDON.getSetting('backup_option_fshare')
    if backup_option_fshare == "true":
        username_backup = ADDON.getSetting('fshare_username')
        password_backup = ADDON.getSetting('fshare_password')
        domain_backup = ADDON.getSetting('domainforfs')
        
        backup_service = "fshare"
    else:
        username_backup = ADDON.getSetting('username_backup')
        password_backup = ADDON.getSetting('password_backup')
        domain_backup = ADDON.getSetting('domainforbackup')
        backup_service=ADDON.getSetting('service.backup')
    if not "@" in username_backup:
        username_backup = username_backup+domain_backup
    USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')
    favourite_file = xbmcvfs.translatePath(USERDATA+"/favourites.xml")
    sources_file=xbmcvfs.translatePath(USERDATA+"/sources.xml")
    #create backupfile
    backup_file = os.path.join(USERDATA, "backup.zip")
    progress = xbmcgui.DialogProgress()
    progress.create('Backup', 'Starting backup...')
    with zipfile.ZipFile(backup_file, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        progress.update(0, 'Backup favourites and sources...')
        # Write the favourite file to the archive
        if os.path.exists(favourite_file):
            zip_file.write(favourite_file, 'favourites.xml')
        if os.path.exists(sources_file):
            zip_file.write(sources_file, 'sources.xml')
        total_files = sum(len(files) for _, _, files in os.walk(PROFILE_PATH))
        current_file = 0
        # Write all the files in the profile path to the archive
        for root, dirs, files in os.walk(PROFILE_PATH):
            for file in files:
                file_path = os.path.join(root, file)
                zip_file.write(file_path, os.path.relpath(file_path, PROFILE_PATH))
                current_file += 1
                progress.update(int((float(current_file) / float(total_files)) * 100), 'Writing file {} of {}...'.format(current_file, total_files))
    filesize = os.path.getsize(backup_file)
    filename = os.path.basename(backup_file)
    if "fshare" in backup_service:
        payload = '{"app_key":"dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt","user_email":"'+username_backup+'","password":"'+password_backup+'"}'
        headers = {'cache-control': "no-cache", 'User-Agent': 'kodivietmediaf-K58W6U'}
        response = requests.post('https://api.fshare.vn/api/user/login', data=payload, headers=headers)
        if response.status_code == 200:
            progress.update(10, 'Uploading backup file to Fshare...')
            jStr = json.loads(response.content)
            token = jStr['token']
            session_id = jStr['session_id']
            headers = {'accept': 'application/json','User-Agent': 'kodivietmediaf-K58W6U','Cookie': 'session_id='+session_id,'Content-Type': 'application/json; charset=UTF-8'}
            json_data = {'name': filename,'size': str(filesize),'path': '/','token': token,'secured': 1}
            cookies = {'session_id':session_id}
            #Check file backup exits or not
            r = urlquick.get('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60', headers=headers, verify=False)
            jdata = json.loads(r.content)
            for i in jdata:
                if i["name"] == "backup.zip":
                    linkcode = i["linkcode"]
                    delete_api = "https://api.fshare.vn/api/fileops/delete"
                    payload = {"token": token,"items": [linkcode]}
                    cookies = {'session_id': session_id}
                    headers = {
                      'Content-Type': 'application/json; charset=UTF-8',
                      'User-Agent': 'kodivietmediaf-K58W6U',
                      'Fshare-Session-ID': session_id
                    }
                    r = requests.post(delete_api, cookies=cookies, headers=headers, json=payload)
                    '''
                    if r.status_code == 200:
                        notify("Đã xoá file cũ")
                    '''
                    break
            progress.update(80, 'Uploading backup file to Fshare...')
            response = requests.post('https://api.fshare.vn/api/session/upload', cookies=cookies, headers=headers, json=json_data)
            r = json.loads(response.content)
            upload_link = r["location"]
            
            with open(backup_file, 'rb') as f:
                binary_data = f.read()
            r = requests.post(upload_link, data=binary_data, headers=headers)
            if r.status_code == 200:
                os.remove(backup_file)
                headers = {'Cookie': 'session_id=' + session_id}
                r = urlquick.get("https://api.fshare.vn//api/user/logout", headers=headers)
                if response.status_code == 200:
                    progress.update(100, 'Lưu trữ thành công...')
        elif response.status_code == 424:
            alert("Bạn đăng nhập sai quá 3 lần. Vui lòng đăng nhập lại")
        elif response.status_code == 409:
            alert("Account đã bị khoá login")
        else:
            alert("Kiểm tra lại tài khoản của bạn")
        
                
    elif "4share" in backup_service:
        #notify("upload lên tài khoản 4fshare %s" % username_backup)
        alert("Phiên bản tiếp")
def restore():
    import zipfile
    backup_option_fshare = ADDON.getSetting('backup_option_fshare')
    if backup_option_fshare == "true":
        username_backup = ADDON.getSetting('fshare_username')
        password_backup = ADDON.getSetting('fshare_password')
        domain_backup = ADDON.getSetting('domainforfs')
        
        backup_service = "fshare"
    else:
        username_backup = ADDON.getSetting('username_backup')
        password_backup = ADDON.getSetting('password_backup')
        domain_backup = ADDON.getSetting('domainforbackup')
        backup_service=ADDON.getSetting('service.backup')
    if not "@" in username_backup:
        username_backup = username_backup+domain_backup
    
    USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')
    
    if len(username_backup) > 0 and len(username_backup) > 0:
        progress = xbmcgui.DialogProgress()
        progress.create('Restore', 'Starting restore...')
        if not "@" in username_backup:
            username_backup = username_backup+domain_backup
        payload = '{"app_key":"dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt","user_email":"'+username_backup+'","password":"'+password_backup+'"}'
        headers = {'cache-control': "no-cache", 'User-Agent': 'kodivietmediaf-K58W6U'}
        response = requests.post('https://api.fshare.vn/api/user/login', data=payload, headers=headers)
        if response.status_code == 200:
            progress.update(0, 'Đang login tài khoản...')
            jStr = json.loads(response.content)
            token = jStr['token']
            session_id = jStr['session_id']
            headers = {'accept': 'application/json','User-Agent': 'kodivietmediaf-K58W6U','Cookie': 'session_id='+session_id,'Content-Type': 'application/json; charset=UTF-8'}
            cookies = {'session_id':session_id}
            #Check file backup exits or not
            r = urlquick.get('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60', headers=headers, verify=False)
            jdata = json.loads(r.content)
            progress.update(1, 'Đang tìm kiếm file backup...')
            import shutil
            for i in jdata:
                if i["name"] == "backup.zip":
                    progress.update(20, 'Đã tìm thấy file backup...')
                    linkcode = i["linkcode"]
                    
                    get_link = 'https://api2.fshare.vn/api/session/download'
                    link_backup = "https://www.fshare.vn/file/"+linkcode
                    
                    data   = '{"token" : "%s", "url" : "%s", "password" : ""}'
                    data   = data % (token, link_backup)
                    header = {'Cookie' : 'session_id=' + session_id}
                    result = requests.post(get_link, headers=header, data=data)
                    jStr = json.loads(result.content)
                    backup_url = jStr['location']
                    backup_file_path = xbmcvfs.translatePath(USERDATA+"/backup.zip")
                    progress.update(40, 'Tải file backup...')
                    urllib.request.urlretrieve(backup_url, backup_file_path)
                    progress.update(60, 'Extract đữ liệu...')
                    with zipfile.ZipFile(backup_file_path, 'r') as zip_ref:
                        zip_ref.extractall(PROFILE_PATH)
                    progress.update(80, 'Phục hồi favourite...')
                    for root, dirs, files in os.walk(PROFILE_PATH):
                        if "favourites.xml" in files:
                            fav_file_src = xbmcvfs.translatePath(PROFILE_PATH + "/favourites.xml")
                            fav_file_dest = xbmcvfs.translatePath(USERDATA + "/favourites.xml")
                            shutil.copyfile(fav_file_src, fav_file_dest)
                        if "sources.xml" in files:
                            sources_file_src = xbmcvfs.translatePath(PROFILE_PATH + "/sources.xml")
                            sources_file_dest = xbmcvfs.translatePath(USERDATA + "/sources.xml")
                            shutil.copyfile(sources_file_src, sources_file_dest)
                            
                    progress.update(90, 'Xoá file tải về...')
                    os.remove(backup_file_path)
                    backup_file_temp = xbmcvfs.translatePath(PROFILE_PATH+"/backup.zip")
                    if os.path.exists(backup_file_temp):os.remove(backup_file_temp)
                    
                    r = urlquick.get("https://api.fshare.vn//api/user/logout", headers=headers)
                    if response.status_code == 200:
                        progress.update(100, 'Phục hồi thành công...')
                    xbmc.executebuiltin('XBMC.ReloadSkin()')
                    xbmc.executebuiltin('XBMC.Container.Refresh')
                    xbmc.executebuiltin('XBMC.Container.Update')
                    
    else:
        alert("Bạn chưa nhập tài khoản để lưu trữ dữ liệu")
def view_debug_log():

    log_path = xbmc.translatePath("special://logpath/kodi.log")
    with open(log_path, "r", encoding="utf-8") as log_file:
        log_contents = log_file.read()
    addon_log_contents = ""
    with open(log_path, "r", encoding="utf-8") as log_file:
        for line in log_file:
            if "plugin.video.vietmediaf" in line:
                addon_log_contents += line
    log_window = xbmcgui.WindowDialog()
    log_window.setProperty("header", "Debug Log")
    log_window.setProperty("text", addon_log_contents)
    log_window.doModal()

    del addon_log_contents    
    
                
    
def play(data):
    link = data["url"]
    #debug(link)
    if link is None or len(link) == 0:
        notify('Không lấy được link')
        return
    if 'PIC' in link:
        imgSrc = link.replace('PIC', '')
        xbmc.executebuiltin('ShowPicture('+imgSrc+')')
        return
    if 'DONATION' in link:
        r = urlfetch.get('http://repo.kodi.vn/Phude/Donation.txt')
        TextBoxes(ADDON_NAME, r.body)
        return
    if 'textbox' in link or 'Textbox' in link:
        url1 = str(link).replace("textbox", "")
        content = openURL(url1)
        TextBoxes(ADDON_NAME, content)
        sys.exit()
    if 'text' in link or 'Text' in link:
        content = str(link).replace("text", "")
        TextBoxes(ADDON_NAME, content)
        return
    else:
        if "fshare.vn" in link:
            watchingHistory(link)
        link = getlink.get(link)
        link = urllib.parse.quote(link, safe=':/')
        
        if not link:
            alert("Không lấy được link. Thử lại sau.")
            exit()
        subtitle = ''
        links = link.split('[]')
        if len(links) == 2:
            subtitle = links[1]
        elif data.get('subtitle'):
            subtitle = data.get('subtitle')
            
        link = links[0]
        #item = xbmcgui.ListItem(path=link, thumbnailImage=xbmc.getInfoLabel("ListItem.Art(thumb)"))
        item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        if len(subtitle) > 0:
            useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
            headers = {'User-Agent': useragent}
            xbmc_temp = xbmcvfs.translatePath('special://temp')
            tempdir = os.path.join(xbmc_temp, 'phudeVMF')
            tmp_file = os.path.join(tempdir, "phude.srt")
            try:
                r = urlquick.get(subtitle)
                writesub(r.text)
                xbmc.sleep(500)
                if not "qc" in subtitle:
                    notify("Đã tải được phụ đề.")
            except:pass
            filename = os.path.join(PROFILE_PATH, 'phude.srt')
            xbmc.Player().setSubtitles(filename)
        else:
            xbmc.Player().play(link)
            
    
def go():
    
    url = sys.argv[0].replace("plugin://%s" % ADDON_ID, VIETMEDIA_HOST) + sys.argv[2]
    
    if not "thread_id" in url:
        url = urllib_parse.unquote_plus(url)
    
        return
    if 'tkFshare' in url:
        ADDON.openSettings()
        exit()
    if '_dellink_' in url:
        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):notify('Bạn chưa có link nào được lưu.')
        else:
            with open(filename, "w") as f:
                lines = f.write('')
                notify('Done')
        return
    
    if 'textbox' in url or 'Textbox' in url:
        import requests
        url = url.replace(VIETMEDIA_HOST + '/?action=textbox&', '')
        url = urllib_parse.unquote_plus(url)
        content = urlquick.get(url).text
        TextBoxes(ADDON_NAME, content)
        exit()
    
        exit()
    if 'check_fshare' in url:
        # notify('đang check')
        check_fshare()
        exit()
        
        
    if 'getfolderfiles' in url:
        notify("external service")
        current = url.replace('http://vietmediaf.net/kodi1.php/?action=getfolderfiles&url=', '')
        url = "http://kodi.s2lsolutions.com/get-folder-files.php?author=cGhvbmdibGFjaw&url=" + current
        url = urllib_parse.unquote(url)
    if '__subtitle__' in url:
        match = re.search(r"file_name=(.+)", url)
        name = match.group(1)
        name = name.replace('.', ' ')
        subtitle_searching(name)
        return
    
    
    
    elif 'play_file' in url:
        data = play_file()
        data = json.loads(data)
        loadlistitem.list_item(data)
    elif 'add_file' in url:
        # Input link by user
        keyboardHandle = xbmc.Keyboard('','[COLOR yellow]Nhập link Folder hoặc File Fshare của bạn:[/COLOR] [I]Nhập ID của Fshare[/I]')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                sys.exit()
        if "fshare.vn" in queryText:
            url_input = queryText.replace("http://", "https://")
            if 'token' in url_input:
                match = re.search(r"(\?.+?\d+)", url_input)
                _token = match.group(1)
                url_input = url_input.replace(_token, '')
            elif len(queryText) == 12 or len(queryText) == 15:
                # check if Fshare id
                queryText = queryText.upper()
                url_input = 'https://www.fshare.vn/file/' + queryText
        else:
            url_input = queryText
            # Check status of link
            url_input = url_input.strip()
            if 'fshare' in url_input:
                if 'folder' in url_input:
                    regex = r"folder\/(.+)"
                else:
                    regex = r"file\/(.+)"
                    match = re.search(regex, url_input)
                    f_id = match.group(1)
            file_type, name, file_size = getlink.check_file_info(url_input)
            # Identify link type
            if file_type == '0':
                file = 'https://www.fshare.vn/folder/' + f_id
            elif file_type == '1':
                file = 'https://www.fshare.vn/file/' + f_id
            elif file_type == '404':
                alert("File bạn nhập không có thực")
                return
            else:
                file = url_input
                # file content
                url = 'Size:' + file_size + 'Name:' + urllib_parse.quote_plus(name.encode("utf8")) + 'Link:' + file
                # Generate file
                filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
                if not os.path.exists(filename):
                    with open(filename, "w+") as f:
                        f.write(url + '*')
                else:
                    with open(filename, "r+") as f:
                        lines = f.read()
                        f.seek(0, 0)
                        f.write(url.rstrip('\r\n') + '*' + lines)
                        notify('Đã lưu link của bạn.')
                return
    elif 'load_file' in url:
        # Loading save file
        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
        else:
            with open(filename, "r") as f:
                lines = f.read()
                lines = lines.rstrip('*')
                if str(len(lines)) == '0':
                    alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
                    return
            lines = lines.split('*')
            t = len(lines)
            items = []
            for i in range(0, t):
                item = {}
                line = (lines[i])
                link = re.search(r"Link:(.+)", line).group(1)
                name = re.search(r"Name:(.+?)Link", line).group(1)
                size = re.search(r"Size:(.+?)Name", line).group(1)
                name = urllib_parse.unquote_plus(name)
                if 'fshare' in link:
                    if 'folder' in link:
                        playable = False
                        link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
                    elif 'file' in link:
                        playable = True
                        link = 'plugin://plugin.video.vietmediaF?action=play&url=%s' % link
                    else:
                        playable = True
                        link = link
                        # Content of file
                        item["label"] = size + ' GB - ' + name
                        item["is_playable"] = playable
                        item["path"] = link
                        item["thumbnail"] = ''
                        item["icon"] = ""
                        item["label2"] = ""
                        item["info"] = {'plot': ''}
                        items += [item]
                data = {"content_type": "episodes", "items": ""}
                data.update({"items": items})
                loadlistitem.list_item(data)
    
def list_menu_items():
    #Run context menu
    url = sys.argv[0].replace("plugin://%s" % ADDON_ID, VIETMEDIA_HOST) + sys.argv[2]
    url = urllib.parse.unquote(url)
    if url == VIETMEDIA_HOST + '/':
        url += '?action=menu'
    '''
    play code
    '''
    match = re.search(r"&d=(.*)",url)
    #Context Menu
    if match:
        keyword = match.group(1)
        if "__removeHistoryPlaycode__" in url:
            link = re.search(r"url=(http.*?)&d", url).group(1)
            file = os.path.join(PROFILE_PATH, 'history.dat')
            filetam = os.path.join(PROFILE_PATH, 'temp.dat')
            if os.path.exists(file):
                with open(file, "r", encoding="utf-8") as input_file, open(filetam, "w", encoding="utf-8") as output_file:
                    for line in input_file:
                        if link not in line.strip("\n"):
                            output_file.write(line)
                os.replace(filetam, file)
                alert("Đã xoá xong")
            else:
                alert("Không tìm thấy tệp history.dat") 
            if os.path.exists(file):
                file_size = os.path.getsize(file)
                if (int(file_size)) > 0:
                    xbmc.executebuiltin("Container.Refresh")
            exit()
        if "__removeAllWatchedHistory__" in url:
            file = os.path.join(PROFILE_PATH, 'watched.dat')
            open(file, 'w').close()
            notify("Đã xoá lịch sử xem phim")
            xbmc.executebuiltin("Container.Refresh")
        if '__lock__' in url:
            add_lock_dir(url)
            
        if '__unlock__' in url:
            remove_lock_dir(url)
            return
        if '__qrlink__' in url:
            qrlink(url)
        if '__addtofav__' in url:
            if "fshare.vn/file" in url:
                match = re.search(r"url=(https:\/\/www.fshare.vn.*)",url)
                if match:
                    url = match.group(1)
                    url = url.replace("[]","")
                    url = url.replace("&d=__addtofav__","")
                    add_remove_favourite(url,"1")
            else:
                link = fetch_data(url)
                if link.get("url"):
                    link = link["url"]
                    if "fshare.vn" in link:
                        add_remove_favourite(link,"1")
                    else:
                        notify("Đây không phải là link fshare")
                        return False
                else:
                    alert("Không lấy được link")
        if '__removeFromfav__' in url:
            if "fshare.vn" in url:
                regex = r"(https://www.fshare.vn.*)&d"
                match = re.search(regex,url)
                link = match.group(1)
                add_remove_favourite(link,"0")
            else:
                notify("Đây không phải là link Fshare")
                return False
        if '__exitKodi__' in url:
            xbmc.executebuiltin("Quit()")
        if "__GoToMyAddon__" in url:
            TextBoxes("path",url)



    
    #Main Function in addon
    else:
        #FUNCTION OF ADDON 
        if "__forbiddenZone__" in url:
            
            lock_icon = xbmcvfs.translatePath('special://home/addons/'+ADDON_ID+'/lock.png')
            lock_dir = os.path.join(PROFILE_PATH, 'lock_dir.dat')
            if not os.path.exists(lock_dir):
                notify("Chưa có gì bí mật để giấu")
                
            items = []
            with open(lock_dir, "r") as f:
                lines = f.readlines()
                t = (len(lines))
                
                for line in lines:
                    item={}
                    
                    if "/folder/" in line or "/d/" in line or "browse" in line or "docs.google.com" in line or "episodes" in line:
                        playable = False
                        line = line.replace("url=plugin://plugin.video.vietmediaF?action=play&","")
                        
                    else: playable = True
                    link = line.replace("http://vietmediaf.net/kodi.php/","")
                    link = link.replace("http://vietmediaf.net/kodi1.php/","")
                    link = link.replace("http://vietmediaf.net/kodi3.php/","")
                    if "thread_id" in line or "node_id" in line:
                        regex = r"(\?action.*)"
                    else:
                        regex = r"url=(https?://\S+)"
                    if match:
                        
                        match = re.search(regex,link)
                        link = match.group(1)
                        link = "?url="+link
                    link = link.replace("\n","")
                    name = "[COLOR yellow][I]Mục bị khoá[/I][/COLOR]"
                    
                    size = ""
                    item["label"] = name
                    item["is_playable"] = playable
                    #item["path"] = 'plugin://plugin.video.vietmediaF%s' % line
                    item["path"] = 'plugin://plugin.video.vietmediaF%s' % link
                    item["icon"] = "https://i.imgur.com/pHbuVqt.png"
                    item["info"] = {'plot': 'Mục lưu trữ cần mật khẩu mở khoá'}
                    item["label2"] = ""
                    item["thumbnail"] = lock_icon
                    item["art"] = {
                        "fanart":lock_icon,
                        "icon"  :lock_icon, 
                        "poster":lock_icon,
                        "thumb":lock_icon
                        }
                    items += [item]
            data = {"content_type": "episodes", "items": ""}
            data.update({"items": items})
            loadlistitem.list_item_main(data)
            
        if "__backup__" in url:
            backup()
        if "__restore__" in url:
            restore()
        
        if 'textbox' in url or 'Textbox' in url:
            url = url.replace(VIETMEDIA_HOST + '/?action=textbox&', '')
            url = urllib_parse.unquote_plus(url)
            content = urlquick.get(url).text
            TextBoxes(ADDON_NAME, content)
        if 'clearCache' in url:
            clear_cache()
        if 'addon' in url:
            install_repo(url)
        if 'checkupdate' in url:
            check_new_version()
            xbmc.executebuiltin('UpdateAddonRepos()')
            xbmc.executebuiltin('UpdateLocalAddons()')
            xbmc.executebuiltin('Addons.OpenRepository("repository.xbmc.org")')
            xbmc.executebuiltin('Addons.UpdateAll()')
            notify('Đã check xong')
        if '__exitKodi__' in url:
            xbmc.executebuiltin("Quit()")
        if '__restartKodi__' in url:
            xbmc.executebuiltin('RestartApp')
        if '__search__' in url:
            keyboardHandle = xbmc.Keyboard('', 'VietmediaF')
            keyboardHandle.doModal()
            if (keyboardHandle.isConfirmed()):
                queryText = keyboardHandle.getText()
                if len(queryText) == 0:
                    return False
                queryText = urllib_parse.quote_plus(queryText)
                url = url.replace('__search__', queryText)
        
        if 'viewlog' in url:
            #view_debug_log()
            
            log_file = xbmcvfs.File(xbmcvfs.translatePath('special://logpath/kodi.log'))
            log_content = log_file.read()
            log_lines = log_content.split('\n')
            error_lines = [line for line in log_lines if 'ERROR' in line]
            error_text = '\n'.join(error_lines)
            dialog = xbmcgui.Dialog()
            dialog.textviewer('Kodi Log (Errors Only)', error_text)
            
        if '_debug_' in url:
            xbmc.executebuiltin('RunAddon("script.kodi.loguploader")')
        if check_lock(url):
            dialog = xbmcgui.Dialog()
            result = dialog.input('Nhập mã khoá', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if len(result) == 0 or result != LOCK_PIN:
                alert('Sai mật mã, vui lòng nhập lại')
                exit()
        if "__timkiem__" in url:
            timkiemMenu()
        if "_timtrenfshare_" in url:
            file = os.path.join(PROFILE_PATH, 'lstk.dat')
            if not os.path.exists(file):
                FshareSearchQuery()
            else:
                data = searchHistory()
                loadlistitem.list_item_search_history(data)
        if "_timtrenfshare1_" in url:
            if not "keyword" in url:
                FshareSearchQuery()
            else:
                match = re.search(r"keyword=(.*)",url)
                if match:
                    query = match.group(1)
                    data=search.searchPhongblack1(query)
                    loadlistitem.list_item_search_history(data)
                else:
                    alert("Không lấy được từ khoá tìm kiếm")
        if '__TIMFSHARE__' in url:
            match = re.search(r"keyword=(.*)",url)
            if match:query = match.group(1)
            data = search.timfshare(query)
            loadlistitem.list_item_search_history(data)
        if "__searchTVHD__" in url:
            keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                query = keyboard.getText()
                search.searchtvhd(query)
        if '__TIMTVHD__' in url:
            match = re.search(r"keyword=(.*)",url)
            if match:query = match.group(1)
            search.searchtvhd(query)
            #loadlistitem.list_item_search_history(data)
            
        if '__removeAllSearchHistory__' in url:
            file = os.path.join(PROFILE_PATH, 'lstk.dat')
            open(file, 'w').close()
            notify("Đã xoá lịch sử tìm kiếm")
            xbmc.executebuiltin("Container.Refresh")
        if "__removeAllSearchHistory4share__" in url:
            file = os.path.join(PROFILE_PATH, 'lstk4s.dat')
            open(file, 'w').close()
            notify("Đã xoá lịch sử tìm kiếm")
            xbmc.executebuiltin("Container.Refresh")
        
        if "_timtren4share_" in url:
            
            file = os.path.join(PROFILE_PATH, 'lstk4s.dat')
            if not os.path.exists(file):
                FourshareSearchQuery(page=1)
            else:
                data = search4sHistory()
                loadlistitem.list_item_search_history(data)
        if "_timtren4share1_" in url:
            if "keyword" in url:
                url = url.replace('%0a', '')
                search_regex = r'keyword=([\w%]+)'
                search_match = re.search(search_regex, url)
                if search_match:
                    query = search_match.group(1)
                    
                if "page" in url:
                    regex = r'page=(\d+)'
                    match = re.search(regex,url)
                    if match:
                        page = match.group(1)
                        data=search.searchFourshare(query,page)
                        loadlistitem.list_item_search_history(data)
                else:
                    page=1
                    data = search.searchFourshare(query,page)
                    loadlistitem.list_item_search_history(data)
            else:
                FourshareSearchQuery(page=1)
            
        
        if '_number_' in url:
            file = os.path.join(PROFILE_PATH, 'history.dat')
            if not os.path.exists(file):
                data = PlayCode()
                loadlistitem.list_item(data)
            else:
                data = history()
                loadlistitem.list_item(data)
            
        if '_number1_' in url:
            data = PlayCode()
            loadlistitem.list_item(data)
            return
        if "docs.google.com" in url:
            regex = r"url=(.+)"
            match = re.search(regex,url)
            link = match.group(1)
            data = google_sheet(link)
            loadlistitem.list_item(data)
        if "__removeAllHistoryPlayCode__" in url:#Xoá lịch sử nhập code
            file = os.path.join(PROFILE_PATH, 'history.dat')
            open(file, 'w').close()
            notify("Đã xoá lịch sử nhập code")
            
        if '__watchedHistoryList__' in url:
            watchedHistoryList()
            #data=watchedHistoryList()
            #loadlistitem.list_item_watched_history(data)
        if '__settings__' in url:
            ADDON.openSettings()
            updateAcc()
            sys.exit()
        if 'account_fshare' in url:
            updateAcc()
            sys.exit()
        if 'fshare.vn' in url and 'folder' in url:
            
            url = urllib_parse.unquote_plus(url)
            if 'api' in url:
                link = re.search(r"url=(.+)",url).group(1) + re.search(r"play(.+)&",url).group(1)
            else:
                regex = r"url=(.+)"
                match = re.search(regex, url)
                link = match.group(1)
                if "page" in url:
                    regex = r"page=(\d+)"
                    match = re.search(regex, url)
                    page = match.group(1)
                    link = link + "page="+page
            #data = fshare_folder(link)
            data = fsharegetFolder(link)
            loadlistitem.list_item(data)
        if 'home_fshare' in url:
            data = fshare_favourite('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60')
            data = json.loads(data)
            loadlistitem.list_item(data)
        if 'follow_fshare' in url:
            data = fshare_favourite('https://api.fshare.vn/api/fileops/getListFollow')
            data = json.loads(data)
            # json.dumps(data)
            loadlistitem.list_item(data)
        if 'folderxxx' in url:
            data = fshare_favourite('https://api.fshare.vn/api/Fileops/ListFavorite')
            data = json.loads(data)
            loadlistitem.list_item(data)
        if 'TopFollowMovie' in url:
            data = fshare_favourite('https://api.fshare.vn//api/fileops/getTopFollowMovie')
            data = json.loads(data)
            loadlistitem.list_item(data)
        if "top_follow_share" in url:
            data = fshare_top_follow()
            data = json.loads(data)
            loadlistitem.list_item(data)
        if ("4share.vn" in url and "/d/" in url) or "api.4share.vn" in url:
            
            regex = r"url=(.+)"
            match = re.search(regex,url)
            link = match.group(1)
            link = link.replace('http','https')
            
            fourshare_folder(link)
            #data = fourshare_folder(link)
            #loadlistitem.list_item(data)
        if '4share.vn/f/' in url or'fshare.vn/file/' in url or 'ok.ru' in url or 'drive.google.com' in url:
            regex = r"url=(.+)"
            match = re.search(regex, url)
            links = match.group(1)
            
            subtitle = ''
            if '[]' in links:
                links = links.split('[]')
                if len(links) == 2:
                    subtitle = links[1]
                link = links[0]
            else:link=links
            data = {"url": "", "subtitle": ""}
            data.update({"url": link, "subtitle": subtitle})
            play(data)
        '''
        elif '4share.vn/d/' in url or 'api.4share.vn' in url:
            regex = r"url=(.+)"
            match = re.search(regex,url)
            if match:
                link = match.group(1)
                data = fourshare_folder(link)
                loadlistitem.list_item(data)
        '''
        if 'get_user_information_fourshare' in url:
            url_get_user_information='https://api.4share.vn/api/v1/?cmd=get_user_info'
            token_4s = getlink.check_token_4s()
            headers = {"accesstoken01":token_4s}
            r = urlquick.get(url_get_user_information,headers=headers)
            json_data = json.loads(r.content)
            errorNumber = list(json_data.values())[0]
            if "100" in str(errorNumber):
                alert("Tài khoản không phải là vip hoặc user/mật khẩu sai")
            else:
                mail_fourshare = list(json_data.values())[1]["email"]
                expire_date = list(json_data.values())[1]["vip_time"]
                line = 'E-mail: [COLOR yellow]%s[/COLOR]\n' % mail_fourshare
                line+= "Loại tài khoản: VIP\n"  
                line+= "Thời gian hết hạn: %s" % expire_date
                alert(line,title="4share account")
                
        
        if 'VMF' in url and not 'action=fetch_espisode' in url:
            
            url = urllib_parse.unquote_plus(url)
            url = url.replace('VMF-', '')
            regex = r"url=(.+)"
            match = re.search(regex, url)
            links = match.group(1)
            data = list_link(links)
            loadlistitem.list_item(data)
        if 'episodes&thread_id' in url:
            
            data = fetch_data(url)
            
            del data["items"][-1]
            
            progress_dialog = xbmcgui.DialogProgress()
            progress_dialog.create('Check link', 'Please wait...')
            x = 0
            for i in data["items"]:
                link = i["path"]
                link = link.replace('plugin://'+ADDON_ID,VIETMEDIA_HOST)
                
                link = fetch_data(link)
                
                if link.get("url"):
                    link = link["url"]
                    if "fshare.vn" in link:
                        name,file_type,size_file = getlink.get_fshare_file_info(link)
                    if "4share.vn" in link:
                        name,size_file = getlink.get_4file_information(link)
                    i["label"] = name
                    i["info"] = {'size': size_file}
                    i["path"] = ('plugin://plugin.video.vietmediaF?action=play&url= %s' % link )
                x+=1            
                '''
                if "4share.vn" in i["path"]:
                    _url = urllib.parse.unquote(i["path"])
                    alert(_url)
                    regex = r"url=([^&]*)"
                    match = re.search(regex, _url)
                    if match:
                        _link = match.group(1)
                        path = ('plugin://'+ADDON_ID+'?url=%s' % _link)
                        i["path"] = path
                '''    
                progress_dialog.update(int(x * 100 / len(data["items"])), 'Updating link information...')
            
            progress_dialog.close()
            #debug(str(data))
            loadlistitem.list_item(data)
        else:
            
            try:
                
                data = fetch_data(url)
                
                if data.get("url"):
                    play(data)
                else:
                    loadlistitem.list_item_main(data)
            except:
                sys.exit()
def plugin_main():
    xbmcplugin.setContent(int(sys.argv[1]), 'videos')
    list_menu_items()
    
if __name__ == '__main__':
    check_new_version()
    plugin_main()